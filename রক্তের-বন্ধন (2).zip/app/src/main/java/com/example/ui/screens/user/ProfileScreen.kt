package com.example.ui.screens.user

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.History
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.BloodGroupBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NeumorphicCard
import com.example.ui.theme.CrimsonPrimary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateToAdminPanel: () -> Unit,
    onSignOut: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedSection by remember { mutableIntStateOf(0) } // 0: রক্তদান ইতিহাস, 1: আমার আবেদন

    val allDonations by repository.getDonationsFlow().collectAsState(initial = emptyList())
    val myDonations = allDonations.filter { it.donorUid == currentUserProfile?.uid }

    val userRequests by if (currentUserProfile != null) {
        repository.getUserBloodRequestsFlow(currentUserProfile.uid).collectAsState(initial = emptyList())
    } else {
        remember { mutableStateOf(emptyList<BloodRequest>()) }
    }

    val allDonors by repository.getDonorsFlow().collectAsState(initial = emptyList())
    val myDonorProfile = allDonors.find { it.uid == currentUserProfile?.uid }

    var isAvailable by remember(myDonorProfile?.isAvailable) {
        mutableStateOf(myDonorProfile?.isAvailable ?: true)
    }

    var requestToFulfill by remember { mutableStateOf<BloodRequest?>(null) }
    var fulfillmentDonorName by remember { mutableStateOf("") }
    var fulfillmentDonorUid by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("প্রোফাইল ও রক্তদান তথ্য", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onSignOut) {
                        Icon(Icons.Default.Logout, contentDescription = "Sign Out", tint = CrimsonPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Card
            item {
                NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFEBEE))
                                .border(2.dp, CrimsonPrimary, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = currentUserProfile?.name?.take(1)?.uppercase() ?: "U",
                                fontSize = 26.sp,
                                fontWeight = FontWeight.Black,
                                color = CrimsonPrimary
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentUserProfile?.name ?: "সদস্য",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (currentUserProfile?.bloodGroup?.isNotBlank() == true) {
                                    BloodGroupBadge(bloodGroup = currentUserProfile.bloodGroup, size = 28.dp)
                                }
                            }

                            Text(
                                text = currentUserProfile?.email ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Text(
                                text = "মোবাইল: ${currentUserProfile?.maskedPhone ?: ""} | জেলা: ${currentUserProfile?.district ?: ""}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Role Badge
                            val roleText = when (currentUserProfile?.role) {
                                UserProfile.ROLE_SUPER_ADMIN -> "সুপার অ্যাডমিন (Super Admin)"
                                UserProfile.ROLE_ADMIN -> "অ্যাডমিন (Admin)"
                                else -> "সাধারণ সদস্য (Member)"
                            }
                            Surface(
                                color = if (currentUserProfile?.isAdminOrHigher == true) Color(0xFFFFEBEE) else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = roleText,
                                    color = if (currentUserProfile?.isAdminOrHigher == true) CrimsonPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Availability Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "রক্তদানে সর্বদা প্রস্তুত",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        Switch(
                            checked = isAvailable && !(myDonorProfile?.isCurrentlyOnCooldown ?: false),
                            onCheckedChange = { checked ->
                                if (myDonorProfile?.isCurrentlyOnCooldown == true) return@Switch
                                isAvailable = checked
                                currentUserProfile?.let { prof ->
                                    coroutineScope.launch {
                                        repository.updateAvailability(prof.uid, checked)
                                    }
                                }
                            },
                            enabled = !(myDonorProfile?.isCurrentlyOnCooldown ?: false),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = CrimsonPrimary
                            )
                        )
                    }

                    // Admin Shortcut if Admin / Super Admin
                    if (currentUserProfile?.isAdminOrHigher == true) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onNavigateToAdminPanel,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("অ্যাডমিন প্যানেলে প্রবেশ করুন", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Cooldown Details Card
            item {
                NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "রক্তদান ও কুলডাউন স্থিতি",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val isOnCooldown = myDonorProfile?.isCurrentlyOnCooldown == true
                    val totalDays = if (currentUserProfile?.gender.equals("female", ignoreCase = true)) 120 else 90

                    if (isOnCooldown) {
                        val remainingDays = myDonorProfile?.cooldownDaysRemaining ?: 0
                        Surface(
                            color = Color(0xFFFFEBEE),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "⚠️ কুলডাউন সক্রিয়: আর $remainingDays দিন বাকি",
                                    color = CrimsonPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "স্বাস্থ্যবিধি অনুযায়ী ${if (currentUserProfile?.gender == "female") "নারীদের জন্য ১২০ দিন" else "পুরুষদের জন্য ৯০ দিন"} পর পুনরায় রক্তদান করা নিরাপদ।",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    } else {
                        Surface(
                            color = Color(0xFFE8F5E9),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "আপনি শারীরিকভাবে সুস্থ থাকলে রক্তদান করতে পারেন।",
                                    color = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            // Section Selector: রক্তদান ইতিহাস vs আমার আবেদন
            item {
                TabRow(
                    selectedTabIndex = selectedSection,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = CrimsonPrimary
                ) {
                    Tab(
                        selected = selectedSection == 0,
                        onClick = { selectedSection = 0 },
                        text = {
                            Text("রক্তদান ইতিহাস (${myDonations.size})", fontWeight = if (selectedSection == 0) FontWeight.Bold else FontWeight.Normal)
                        }
                    )
                    Tab(
                        selected = selectedSection == 1,
                        onClick = { selectedSection = 1 },
                        text = {
                            Text("আমার আবেদন (${userRequests.size})", fontWeight = if (selectedSection == 1) FontWeight.Bold else FontWeight.Normal)
                        }
                    )
                }
            }

            if (selectedSection == 0) {
                if (myDonations.isEmpty()) {
                    item {
                        EmptyStateView(
                            title = "এখনো কোনো তথ্য নেই",
                            subtitle = "আপনার কোনো রক্তদানের ইতিহাস পাওয়া যায়নি। রক্তদান সম্পন্ন হলে এখানে তা নথিভুক্ত হবে।",
                            icon = Icons.Outlined.History
                        )
                    }
                } else {
                    items(myDonations) { donation ->
                        DonationRecordCard(record = donation)
                    }
                }
            } else {
                if (userRequests.isEmpty()) {
                    item {
                        EmptyStateView(
                            title = "এখনো কোনো তথ্য নেই",
                            subtitle = "আপনি এখনো কোনো রক্তের আবেদন করেননি।",
                            icon = Icons.Outlined.History
                        )
                    }
                } else {
                    items(userRequests) { req ->
                        MyBloodRequestCard(
                            request = req,
                            onMarkFulfilled = {
                                requestToFulfill = req
                                fulfillmentDonorName = req.acceptedDonorName
                                fulfillmentDonorUid = req.acceptedDonorUid
                            }
                        )
                    }
                }
            }
        }

        // Fulfill Request Dialog
        if (requestToFulfill != null) {
            val req = requestToFulfill!!
            AlertDialog(
                onDismissRequest = { requestToFulfill = null },
                title = { Text("রক্তদান সম্পন্ন নিশ্চিতকরণ", fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("রোগী: ${req.patientName} (${req.bloodGroup}, ${req.units} ব্যাগ)")
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = fulfillmentDonorName,
                            onValueChange = { fulfillmentDonorName = it },
                            label = { Text("রক্তদাতার নাম") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "এটি সম্পন্ন হিসেবে চিহ্নিত করলে রক্তদাতার প্রোফাইলে রক্তদানের রেকর্ড যুক্ত হবে এবং তার ৯১/১২০ দিনের কুলডাউন শুরু হবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val donorUidToUpdate = if (fulfillmentDonorUid.isNotBlank()) fulfillmentDonorUid else "manual_donor"
                            coroutineScope.launch {
                                repository.fulfillBloodRequest(
                                    requestId = req.id,
                                    donorUid = donorUidToUpdate,
                                    donorName = fulfillmentDonorName.ifBlank { "সহৃদয় রক্তদাতা" },
                                    bloodGroup = req.bloodGroup,
                                    units = req.units,
                                    patientName = req.patientName,
                                    hospital = req.hospital
                                )
                                requestToFulfill = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("রক্তদান সম্পন্ন করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { requestToFulfill = null }) {
                        Text("বাতিল")
                    }
                }
            )
        }
    }
}

@Composable
fun DonationRecordCard(record: DonationRecord) {
    val dateStr = remember(record.donationDate) {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        sdf.format(Date(record.donationDate))
    }

    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BloodGroupBadge(bloodGroup = record.bloodGroup, size = 42.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "রোগী: ${record.patientName}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "হাসপাতাল: ${record.hospital} | পরিমাণ: ${record.units} ব্যাগ",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "তারিখ: $dateStr",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = CrimsonPrimary,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}

@Composable
fun MyBloodRequestCard(
    request: BloodRequest,
    onMarkFulfilled: () -> Unit
) {
    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BloodGroupBadge(bloodGroup = request.bloodGroup, size = 38.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = request.patientName,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${request.hospital}, ${request.location}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Surface(
                color = when (request.status) {
                    BloodRequest.STATUS_FULFILLED -> Color(0xFFE8F5E9)
                    BloodRequest.STATUS_APPROVED -> Color(0xFFE3F2FD)
                    else -> Color(0xFFFFF3E0)
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = when (request.status) {
                        BloodRequest.STATUS_FULFILLED -> "সম্পন্ন"
                        BloodRequest.STATUS_APPROVED -> "গৃহীত"
                        else -> "অপেক্ষমাণ"
                    },
                    color = when (request.status) {
                        BloodRequest.STATUS_FULFILLED -> Color(0xFF2E7D32)
                        BloodRequest.STATUS_APPROVED -> Color(0xFF1565C0)
                        else -> Color(0xFFE65100)
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                )
            }
        }

        if (request.status != BloodRequest.STATUS_FULFILLED) {
            Spacer(modifier = Modifier.height(10.dp))
            Button(
                onClick = onMarkFulfilled,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("রক্ত পাওয়া গেছে (Fulfilled)")
            }
        }
    }
}
