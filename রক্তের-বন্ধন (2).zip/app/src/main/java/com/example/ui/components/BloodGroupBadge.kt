package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.getBloodGroupColor

@Composable
fun BloodGroupBadge(
    bloodGroup: String,
    modifier: Modifier = Modifier,
    size: Dp = 42.dp,
    showContainerOnly: Boolean = false
) {
    val badgeColor = getBloodGroupColor(bloodGroup)

    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(badgeColor)
            .border(2.dp, Color.White.copy(alpha = 0.8f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = bloodGroup.ifBlank { "?" },
            color = Color.White,
            fontWeight = FontWeight.Black,
            fontSize = if (size < 36.dp) 11.sp else if (size < 50.dp) 14.sp else 18.sp
        )
    }
}

@Composable
fun UrgencyBadge(
    urgency: String,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor, textBangla) = when (urgency.trim().lowercase()) {
        "critical" -> Triple(Color(0xFFFFEBEE), Color(0xFFC62828), "অত্যন্ত জরুরি")
        "urgent" -> Triple(Color(0xFFFFF3E0), Color(0xFFE65100), "জরুরি")
        else -> Triple(Color(0xFFE8F5E9), Color(0xFF2E7D32), "সাধারণ")
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .border(1.dp, textColor.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = textBangla,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
