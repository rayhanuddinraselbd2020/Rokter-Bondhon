package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CrimsonPrimary = Color(0xFFC62828)
val CrimsonPrimaryDark = Color(0xFF8E0000)
val CrimsonPrimaryLight = Color(0xFFFF5F52)

val DeepWineSecondary = Color(0xFF880E4F)
val WarmGoldTertiary = Color(0xFFF57F17)

val LightBackground = Color(0xFFF7F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEF1F6)

val DarkBackground = Color(0xFF141214)
val DarkSurface = Color(0xFF1F1B1E)
val DarkSurfaceVariant = Color(0xFF2C272B)

// Blood Group specific colors
val ColorAPositive = Color(0xFFD32F2F)
val ColorANegative = Color(0xFFC2185B)
val ColorBPositive = Color(0xFFE53935)
val ColorBNegative = Color(0xFFAD1457)
val ColorABPositive = Color(0xFF7B1FA2)
val ColorABNegative = Color(0xFF4A148C)
val ColorOPositive = Color(0xFFB71C1C)
val ColorONegative = Color(0xFF880E4F)

fun getBloodGroupColor(group: String): Color {
    return when (group.trim().uppercase()) {
        "A+" -> ColorAPositive
        "A-" -> ColorANegative
        "B+" -> ColorBPositive
        "B-" -> ColorBNegative
        "AB+" -> ColorABPositive
        "AB-" -> ColorABNegative
        "O+" -> ColorOPositive
        "O-" -> ColorONegative
        else -> CrimsonPrimary
    }
}
