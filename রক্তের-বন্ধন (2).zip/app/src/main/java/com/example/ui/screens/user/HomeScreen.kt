package com.example.ui.screens.user

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Bloodtype
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.*
import com.example.ui.theme.CrimsonPrimary
import com.example.ui.theme.DeepWineSecondary
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateToCreateRequest: () -> Unit,
    onNavigateToDonorSearch: (String?) -> Unit,
    onNavigateToChat: (recipientUid: String, recipientName: String) -> Unit,
    onNavigateToAdminPanel: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToProfile: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    val bloodRequests by repository.getBloodRequestsFlow().collectAsState(initial = emptyList())
    val donors by repository.getDonorsFlow().collectAsState(initial = emptyList())
    val bloodStock by repository.getBloodStockFlow().collectAsState(initial = emptyList())
    val donations by repository.getDonationsFlow().collectAsState(initial = emptyList())
    val notifications by if (currentUserProfile != null) {
        repository.getNotificationsFlow(currentUserProfile.uid).collectAsState(initial = emptyList())
    } else {
        remember { mutableStateOf(emptyList<NotificationItem>()) }
    }

    val unreadCount = notifications.count { !it.isRead }

    // User's own donor profile
    val userDonorProfile = donors.find { it.uid == currentUserProfile?.uid }
    var isAvailable by remember(userDonorProfile?.isAvailable) {
        mutableStateOf(userDonorProfile?.isAvailable ?: true)
    }

    // Urgent and active requests
    val emergencyRequests = bloodRequests.filter {
        (it.urgency == BloodRequest.URGENCY_CRITICAL || it.urgency == BloodRequest.URGENCY_URGENT) &&
                it.status == BloodRequest.STATUS_PENDING
    }
    val activeRecentRequests = bloodRequests.filter { it.status == BloodRequest.STATUS_PENDING }

    // Aggregate statistics directly from Firestore
    val totalDonorsCount = donors.size
    val totalDonatedBags = donations.sumOf { it.units }
    val activeRequestsCount = activeRecentRequests.size
    val totalStockBags = bloodStock.sumOf { it.availableBags }

    Scaffold(
        topBar = {
            TopHeaderBar(
                userProfile = currentUserProfile,
                unreadNotificationCount = unreadCount,
                onNotificationClick = onNavigateToNotifications,
                onProfileClick = onNavigateToProfile,
                onAdminPanelClick = if (currentUserProfile?.isAdminOrHigher == true) onNavigateToAdminPanel else null
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Big Emergency CTA Button: "🆘 Need Blood" (রক্তের প্রয়োজন)
            item {
                Card(
                    onClick = onNavigateToCreateRequest,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(76.dp),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(CrimsonPrimary, Color(0xFFE53935), DeepWineSecondary)
                                )
                            )
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = "রক্তের প্রয়োজন? (Need Blood)",
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        text = "জরুরি রিকোয়েস্ট তৈরি করুন",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 12.sp
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.AddCircle,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }
            }

            // Availability Toggle & Cooldown Card
            item {
                NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "আমি রক্তদানে প্রস্তুত",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (currentUserProfile?.bloodGroup?.isNotBlank() == true) {
                                    BloodGroupBadge(
                                        bloodGroup = currentUserProfile.bloodGroup,
                                        size = 28.dp
                                    )
                                }
                            }
                            Text(
                                text = if (userDonorProfile?.isCurrentlyOnCooldown == true) {
                                    "কুলডাউন সক্রিয়: আর ${userDonorProfile.cooldownDaysRemaining} দিন পর রক্তদান করতে পারবেন"
                                } else if (isAvailable) {
                                    "আপনার প্রোফাইল রক্তগ্রহীতাদের তালিকায় দৃশ্যমান"
                                } else {
                                    "বর্তমানে আপনি রক্তদানে অপ্রস্তুত হিসেবে চিহ্নিত"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (userDonorProfile?.isCurrentlyOnCooldown == true) CrimsonPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Switch(
                            checked = isAvailable && !(userDonorProfile?.isCurrentlyOnCooldown ?: false),
                            onCheckedChange = { checked ->
                                if (userDonorProfile?.isCurrentlyOnCooldown == true) return@Switch
                                isAvailable = checked
                                currentUserProfile?.let { prof ->
                                    coroutineScope.launch {
                                        repository.updateAvailability(prof.uid, checked)
                                    }
                                }
                            },
                            enabled = !(userDonorProfile?.isCurrentlyOnCooldown ?: false),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = CrimsonPrimary
                            )
                        )
                    }

                    // Cooldown progress indicator if active
                    if (userDonorProfile?.isCurrentlyOnCooldown == true) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val totalCooldownDays = if (userDonorProfile.gender.equals("female", ignoreCase = true)) 120f else 90f
                        val daysRemaining = userDonorProfile.cooldownDaysRemaining.toFloat()
                        val progress = ((totalCooldownDays - daysRemaining) / totalCooldownDays).coerceIn(0f, 1f)

                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = CrimsonPrimary,
                            trackColor = Color(0xFFFFEBEE)
                        )
                    }
                }
            }

            // Organization Statistics (Live Firestore aggregation - No mock data!)
            item {
                Column {
                    Text(
                        text = "সংগঠনের সামগ্রিক পরিসংখ্যান",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            label = "মোট রক্তদাতা",
                            value = totalDonorsCount.toString(),
                            icon = Icons.Default.People,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "মোট রক্তদান",
                            value = "$totalDonatedBags ব্যাগ",
                            icon = Icons.Default.Favorite,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatCard(
                            label = "সক্রিয় অনুরোধ",
                            value = activeRequestsCount.toString(),
                            icon = Icons.Default.HourglassTop,
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "ব্লাড স্টক",
                            value = "$totalStockBags ব্যাগ",
                            icon = Icons.Default.LocalHospital,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Urgent / Critical Emergency Requests Section
            if (emergencyRequests.isNotEmpty()) {
                item {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Emergency,
                                    contentDescription = null,
                                    tint = CrimsonPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "জরুরি রক্তের আবেদন (${emergencyRequests.size})",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CrimsonPrimary
                                    )
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(emergencyRequests) { req ->
                                EmergencyRequestCard(
                                    request = req,
                                    currentUserId = currentUserProfile?.uid,
                                    onAcceptClick = {
                                        currentUserProfile?.let { user ->
                                            coroutineScope.launch {
                                                repository.acceptBloodRequest(req.id, user.uid, user.name)
                                            }
                                        }
                                    },
                                    onChatClick = {
                                        onNavigateToChat(req.requesterUid, req.requesterName)
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // Recent Blood Requests Section
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "সাম্প্রতিক রক্তের আবেদন",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(onClick = { onNavigateToDonorSearch(null) }) {
                        Text("দাতা খুঁজুন", color = CrimsonPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            if (activeRecentRequests.isEmpty()) {
                item {
                    EmptyStateView(
                        title = "এখনো কোনো তথ্য নেই",
                        subtitle = "বর্তমানে কোনো সক্রিয় রক্তের আবেদন নেই। প্রয়োজনে উপরের বোতাম চেপে আবেদন করুন।",
                        icon = Icons.Outlined.Bloodtype,
                        actionButton = {
                            NeumorphicOutlinedButton(onClick = onNavigateToCreateRequest) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("নতুন আবেদন তৈরি করুন")
                            }
                        }
                    )
                }
            } else {
                items(activeRecentRequests) { req ->
                    BloodRequestCard(
                        request = req,
                        currentUserId = currentUserProfile?.uid,
                        onAcceptClick = {
                            currentUserProfile?.let { user ->
                                coroutineScope.launch {
                                    repository.acceptBloodRequest(req.id, user.uid, user.name)
                                }
                            }
                        },
                        onChatClick = {
                            onNavigateToChat(req.requesterUid, req.requesterName)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun StatCard(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    NeumorphicCard(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFFFFEBEE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = CrimsonPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = value,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun EmergencyRequestCard(
    request: BloodRequest,
    currentUserId: String?,
    onAcceptClick: () -> Unit,
    onChatClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .border(1.5.dp, CrimsonPrimary.copy(alpha = 0.6f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF5F5))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BloodGroupBadge(bloodGroup = request.bloodGroup, size = 36.dp)
                UrgencyBadge(urgency = request.urgency)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "রোগী: ${request.patientName}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "হাসপাতাল: ${request.hospital}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "স্থান: ${request.location} | প্রয়োজন: ${request.units} ব্যাগ",
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                color = CrimsonPrimary
            )
            Spacer(modifier = Modifier.height(12.dp))

            if (request.requesterUid != currentUserId) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onAcceptClick,
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("সাড়া দিন", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onChatClick,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("চ্যাট", fontSize = 13.sp)
                    }
                }
            } else {
                Text(
                    text = "আপনার নিজের আবেদন",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}

@Composable
fun BloodRequestCard(
    request: BloodRequest,
    currentUserId: String?,
    onAcceptClick: () -> Unit,
    onChatClick: () -> Unit
) {
    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BloodGroupBadge(bloodGroup = request.bloodGroup, size = 48.dp)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = request.patientName,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    UrgencyBadge(urgency = request.urgency)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${request.hospital}, ${request.location}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "তারিখ: ${request.requiredDate} | পরিমাণ: ${request.units} ব্যাগ",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = CrimsonPrimary,
                        fontWeight = FontWeight.Medium
                    )
                )
                Text(
                    text = "যোগাযোগ: ${request.maskedContact} (সুরক্ষিত)",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (request.requesterUid != currentUserId) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onAcceptClick,
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                ) {
                    Icon(Icons.Default.VolunteerActivism, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("রক্তদানে রাজি", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onChatClick,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                ) {
                    Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("যোগাযোগ", fontSize = 13.sp)
                }
            }
        }
    }
}
