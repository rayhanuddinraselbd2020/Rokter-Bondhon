package com.example.ui.screens.user

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.BloodCompatibility
import com.example.data.model.BloodRequest
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.BloodGroupBadge
import com.example.ui.components.NeumorphicCard
import com.example.ui.theme.CrimsonPrimary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BloodRequestScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateBack: () -> Unit,
    onRequestCreatedSuccess: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    var patientName by remember { mutableStateOf("") }
    var selectedBloodGroup by remember { mutableStateOf(currentUserProfile?.bloodGroup?.ifBlank { "A+" } ?: "A+") }
    var hospital by remember { mutableStateOf("") }
    var location by remember { mutableStateOf(currentUserProfile?.district ?: "ঢাকা") }
    var requiredDate by remember {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        mutableStateOf(sdf.format(Date()))
    }
    var units by remember { mutableIntStateOf(1) }
    var contactNumber by remember { mutableStateOf(currentUserProfile?.phone ?: "") }
    var urgency by remember { mutableStateOf(BloodRequest.URGENCY_NORMAL) }
    var medicalReportUrl by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successDialogVisible by remember { mutableStateOf(false) }

    val bloodGroups = BloodCompatibility.ALL_BLOOD_GROUPS

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "রক্তের জরুরি আবেদন",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 18.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            // Urgency Banner
            if (urgency == BloodRequest.URGENCY_CRITICAL) {
                Surface(
                    color = Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonPrimary),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = CrimsonPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "অত্যন্ত জরুরি আবেদন: মিল থাকা সকল উপযুক্ত রক্তদাতার কাছে স্বয়ংক্রিয় পুশ নোটিফিকেশন ও অ্যালার্ট পৌঁছাবে।",
                            color = CrimsonPrimary,
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "রোগী ও রক্তের তথ্য",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (errorMessage != null) {
                    Surface(
                        color = Color(0xFFFFEBEE),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = CrimsonPrimary,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Patient Name
                OutlinedTextField(
                    value = patientName,
                    onValueChange = { patientName = it; errorMessage = null },
                    label = { Text("রোগীর নাম (Patient Name)*") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = CrimsonPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Required Blood Group
                Text(
                    text = "প্রয়োজনীয় রক্তের গ্রুপ*",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    bloodGroups.take(4).forEach { bg ->
                        val isSelected = selectedBloodGroup == bg
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) CrimsonPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedBloodGroup = bg }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bg,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    bloodGroups.drop(4).forEach { bg ->
                        val isSelected = selectedBloodGroup == bg
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) CrimsonPrimary else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { selectedBloodGroup = bg }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bg,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Units Needed
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "রক্তের পরিমাণ (ব্যাগ)*",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (units > 1) units-- },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.RemoveCircleOutline, contentDescription = "Decrease")
                        }
                        Text(
                            text = "$units ব্যাগ",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        IconButton(
                            onClick = { if (units < 10) units++ },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.AddCircleOutline, contentDescription = "Increase", tint = CrimsonPrimary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Urgency Level
                Text(
                    text = "জরুরিতার মাত্রা (Urgency)*",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        BloodRequest.URGENCY_NORMAL to "সাধারণ",
                        BloodRequest.URGENCY_URGENT to "জরুরি",
                        BloodRequest.URGENCY_CRITICAL to "অত্যন্ত জরুরি"
                    ).forEach { (level, titleBangla) ->
                        val isSelected = urgency == level
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSelected) {
                                        if (level == BloodRequest.URGENCY_CRITICAL) CrimsonPrimary else Color(0xFFE65100)
                                    } else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .clickable { urgency = level }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = titleBangla,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Hospital
                OutlinedTextField(
                    value = hospital,
                    onValueChange = { hospital = it; errorMessage = null },
                    label = { Text("হাসপাতালের নাম (Hospital Name)*") },
                    leadingIcon = { Icon(Icons.Default.LocalHospital, contentDescription = null, tint = CrimsonPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Location / District
                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it; errorMessage = null },
                    label = { Text("স্থান ও জেলা (Location / District)*") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = CrimsonPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Required Date
                OutlinedTextField(
                    value = requiredDate,
                    onValueChange = { requiredDate = it },
                    label = { Text("রক্তের প্রয়োজনীয় তারিখ (YYYY-MM-DD)*") },
                    leadingIcon = { Icon(Icons.Default.CalendarToday, contentDescription = null, tint = CrimsonPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Contact Number
                OutlinedTextField(
                    value = contactNumber,
                    onValueChange = { contactNumber = it; errorMessage = null },
                    label = { Text("যোগাযোগের মোবাইল নম্বর*") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = CrimsonPrimary) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    supportingText = {
                        Text(
                            text = "গোপনীয়তা রক্ষার্থে সাধারণ ব্যবহারকারীদের কাছে নম্বরটি মাস্কড (আংশিক গোপন) থাকবে।",
                            fontSize = 11.sp
                        )
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Medical Report External CDN Image URL
                OutlinedTextField(
                    value = medicalReportUrl,
                    onValueChange = { medicalReportUrl = it },
                    label = { Text("মেডিকেল রিপোর্ট ছবির URL (ঐচ্ছিক - External CDN)") },
                    leadingIcon = { Icon(Icons.Default.DocumentScanner, contentDescription = null, tint = CrimsonPrimary) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                if (medicalReportUrl.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = medicalReportUrl,
                            contentDescription = "Medical Report Preview",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = {
                        if (patientName.isBlank() || hospital.isBlank() || location.isBlank() || contactNumber.isBlank() || requiredDate.isBlank()) {
                            errorMessage = "অনুগ্রহ করে সকল প্রয়োজনীয় তথ্য সঠিকভাবে পূরণ করুন"
                            return@Button
                        }
                        if (units <= 0) {
                            errorMessage = "রক্তের পরিমাণ ন্যূনতম ১ ব্যাগ হতে হবে"
                            return@Button
                        }

                        isLoading = true
                        errorMessage = null

                        coroutineScope.launch {
                            val newRequest = BloodRequest(
                                patientName = patientName.trim(),
                                bloodGroup = selectedBloodGroup,
                                hospital = hospital.trim(),
                                location = location.trim(),
                                requiredDate = requiredDate.trim(),
                                units = units,
                                contactNumber = contactNumber.trim(),
                                urgency = urgency,
                                medicalReportUrl = medicalReportUrl.trim(),
                                requesterUid = currentUserProfile?.uid ?: "",
                                requesterName = currentUserProfile?.name ?: "সদস্য",
                                status = BloodRequest.STATUS_PENDING
                            )

                            val result = repository.createBloodRequest(newRequest)
                            isLoading = false
                            result.fold(
                                onSuccess = {
                                    successDialogVisible = true
                                },
                                onFailure = { err ->
                                    errorMessage = err.localizedMessage ?: "আবেদন তৈরি করা সম্ভব হয়নি।"
                                }
                            )
                        }
                    },
                    enabled = !isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("রক্তের আবেদন পোস্ট করুন", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }

        if (successDialogVisible) {
            AlertDialog(
                onDismissRequest = {
                    successDialogVisible = false
                    onRequestCreatedSuccess()
                },
                title = {
                    Text("আবেদন সফলভাবে গৃহীত হয়েছে", fontWeight = FontWeight.Bold)
                },
                text = {
                    Text("আপনার রক্তের আবেদনটি সিস্টেমে যুক্ত হয়েছে এবং উপযুক্ত রক্তদাতাদের নোটিফিকেশন প্রদান করা হয়েছে। রক্তদাতা সাড়া দিলে আপনার সাথে চ্যাট বা কলে যোগাযোগ করবেন।")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            successDialogVisible = false
                            onRequestCreatedSuccess()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("ঠিক আছে")
                    }
                }
            )
        }
    }
}
