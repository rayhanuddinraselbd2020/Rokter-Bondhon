package com.example.ui.screens.user

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceItem
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.NeumorphicCard
import com.example.ui.theme.CrimsonPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServicesScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateToCreateBloodRequest: () -> Unit
) {
    var selectedServiceForRequest by remember { mutableStateOf<ServiceItem?>(null) }
    var requestNotes by remember { mutableStateOf("") }
    var showConfirmationDialog by remember { mutableStateOf(false) }

    val services = listOf(
        ServiceItem(
            id = "srv_blood",
            name = "জরুরি রক্তদান সহায়তা",
            description = "রোগীর জন্য জরুরি ভিত্তিতে সামঞ্জস্যপূর্ণ গ্রুপের রক্তদাতা খুঁজে দেওয়া ও রক্তদান প্রক্রিয়া সমন্বয়।",
            iconName = "blood",
            contactNumber = "+8801700000000",
            category = "রক্তদান সেবা"
        ),
        ServiceItem(
            id = "srv_ambulance",
            name = "জরুরি অ্যাম্বুলেন্স সেবা",
            description = "গুরুতর অসুস্থ ও মুমূর্ষু রোগীদের দ্রুত হাসপাতালে স্থানান্তরের জন্য জরুরি অ্যাম্বুলেন্স সহায়তা।",
            iconName = "ambulance",
            contactNumber = "+8801711111111",
            category = "জরুরি পরিবহন"
        ),
        ServiceItem(
            id = "srv_oxygen",
            name = "ফ্রি অক্সিজেন সিলিন্ডার সহায়তা",
            description = "শ্বাসকষ্টে আক্রান্ত রোগী ও দুস্থ পরিবারের জন্য বিনামূল্যে জরুরি অক্সিজেন সিলিন্ডার সরবরাহ।",
            iconName = "oxygen",
            contactNumber = "+8801722222222",
            category = "মেডিকেল এইড"
        ),
        ServiceItem(
            id = "srv_medicine",
            name = "জরুরি ওষুধ ও চিকিৎসা সহায়তা",
            description = "অসহায় ও দরিদ্র রোগীদের ব্যবস্থাপত্র অনুযায়ী জরুরি ওষুধ সরবরাহ ও চিকিৎসা তহবিলে সহায়তা।",
            iconName = "medicine",
            contactNumber = "+8801733333333",
            category = "মেডিকেল এইড"
        ),
        ServiceItem(
            id = "srv_consultation",
            name = "বিনামূল্যে রক্তরোগ ও স্বাস্থ্য পরামর্শ",
            description = "স্বেচ্ছাসেবী চিকিৎসকদের মাধ্যমে রক্তদান সংক্রান্ত ভীতি দূরীকরণ ও সাধারণ চিকিৎসা বিষয়ক পরামর্শ।",
            iconName = "consultation",
            contactNumber = "+8801744444444",
            category = "স্বাস্থ্য পরামর্শ"
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("আমাদের সেবা সমূহ", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Surface(
                    color = Color(0xFFFFEBEE),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "বাংলাদেশ সেবামূলক সংগঠন",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = CrimsonPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "মানবতার কল্যাণে আমাদের সকল কার্যক্রম সম্পূর্ণ অরাজনৈতিক ও নিঃস্বার্থ। যে কোনো জরুরি সেবার জন্য আবেদন করুন বা হটলাইনে যোগাযোগ করুন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            items(services) { service ->
                ServiceCard(
                    service = service,
                    onRequestClick = {
                        if (service.id == "srv_blood") {
                            onNavigateToCreateBloodRequest()
                        } else {
                            selectedServiceForRequest = service
                        }
                    }
                )
            }
        }

        if (selectedServiceForRequest != null) {
            AlertDialog(
                onDismissRequest = { selectedServiceForRequest = null },
                title = {
                    Text(text = "${selectedServiceForRequest?.name} এর জন্য আবেদন", fontWeight = FontWeight.Bold)
                },
                text = {
                    Column {
                        Text("আপনার নাম ও যোগাযোগের নম্বর সিস্টেমে সংরক্ষিত প্রোফাইল থেকে স্বয়ংক্রিয়ভাবে যুক্ত হবে।")
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = requestNotes,
                            onValueChange = { requestNotes = it },
                            label = { Text("প্রয়োজনের বিস্তারিত বিবরণ") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            selectedServiceForRequest = null
                            showConfirmationDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("আবেদন জমা দিন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedServiceForRequest = null }) {
                        Text("বাতিল")
                    }
                }
            )
        }

        if (showConfirmationDialog) {
            AlertDialog(
                onDismissRequest = { showConfirmationDialog = false },
                title = { Text("আবেদন গৃহীত হয়েছে", fontWeight = FontWeight.Bold) },
                text = { Text("আপনার সেবার আবেদনটি সংগঠনের স্বেচ্ছাসেবী দলের কাছে পৌঁছানো হয়েছে। শীঘ্রই আপনার সাথে যোগাযোগ করা হবে।") },
                confirmButton = {
                    Button(
                        onClick = { showConfirmationDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("ঠিক আছে")
                    }
                }
            )
        }
    }
}

@Composable
fun ServiceCard(
    service: ServiceItem,
    onRequestClick: () -> Unit
) {
    val iconVector = when (service.iconName) {
        "blood" -> Icons.Default.Bloodtype
        "ambulance" -> Icons.Default.AirportShuttle
        "oxygen" -> Icons.Default.Air
        "medicine" -> Icons.Default.Medication
        else -> Icons.Default.HealthAndSafety
    }

    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFEBEE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconVector,
                    contentDescription = null,
                    tint = CrimsonPrimary,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = service.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = service.category,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = service.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Button(
                onClick = onRequestClick,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("সেবা গ্রহণ করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}
