package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditLogItem
import com.example.data.model.OrgSettings
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NeumorphicCard
import com.example.ui.theme.CrimsonPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SuperAdminScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateBack: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: সদস্য ও রোল ম্যানেজমেন্ট, 1: অডিট ট্রেইল, 2: সংগঠন সেটিংস

    val members: List<UserProfile> by repository.getAllUsersFlow().collectAsState(initial = emptyList())
    val auditLogs: List<AuditLogItem> by repository.getAuditLogsFlow().collectAsState(initial = emptyList())
    val orgSettings by repository.getOrgSettingsFlow().collectAsState(initial = OrgSettings())

    var searchQuery by remember { mutableStateOf("") }
    var selectedUserForRoleChange by remember { mutableStateOf<UserProfile?>(null) }
    var newSelectedRole by remember { mutableStateOf("admin") }

    // Organization settings editable fields
    var orgName by remember(orgSettings.name) { mutableStateOf(orgSettings.name) }
    var orgTagline by remember(orgSettings.tagline) { mutableStateOf(orgSettings.tagline) }
    var orgHelpline by remember(orgSettings.emergencyHotline) { mutableStateOf(orgSettings.emergencyHotline) }
    var orgAddress by remember(orgSettings.address) { mutableStateOf(orgSettings.address) }
    var settingsSavedMessage by remember { mutableStateOf(false) }

    val filteredMembers: List<UserProfile> = remember(members, searchQuery) {
        if (searchQuery.isBlank()) members
        else members.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
                    it.email.contains(searchQuery, ignoreCase = true) ||
                    it.phone.contains(searchQuery, ignoreCase = true)
        }
    }


    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = CrimsonPrimary, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সুপার অ্যাডমিন নিয়ন্ত্রণ কক্ষ", fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = "সর্বোচ্চ প্রশাসনিক অধিকারপ্রাপ্ত প্যানেল",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CrimsonPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("সদস্য ও দায়িত্ব (${members.size})") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("অডিট ট্রেইল (${auditLogs.size})") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("সংগঠন সেটিংস") }
                )
            }

            when (selectedTab) {
                0 -> {
                    // Member & Role Management
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("নাম, ইমেইল বা ফোন দিয়ে সদস্য খুঁজুন...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        if (filteredMembers.isEmpty()) {
                            EmptyStateView(title = "কোনো সদস্য পাওয়া যায়নি", subtitle = "অন্য কোনো শব্দ দিয়ে খুঁজুন।")
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredMembers) { user ->
                                    MemberRoleCard(
                                        user = user,
                                        isSuperAdmin = user.isSuperAdmin,
                                        onChangeRoleClick = {
                                            selectedUserForRoleChange = user
                                            newSelectedRole = if (user.role == UserProfile.ROLE_ADMIN) UserProfile.ROLE_MEMBER else UserProfile.ROLE_ADMIN
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // Full Audit Trail
                    if (auditLogs.isEmpty()) {
                        EmptyStateView(title = "কোনো অডিট রেকর্ড নেই", subtitle = "সিস্টেমের সকল প্রশাসনিক কার্যক্রমের ইতিহাস এখানে সুরক্ষিত থাকবে।")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(auditLogs) { log ->
                                NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = log.action, fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                                        Text(text = log.performerName, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = log.details, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // Organization Settings
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "সংগঠনের অফিসিয়াল তথ্য ও সেটিংস",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = orgName,
                                onValueChange = { orgName = it },
                                label = { Text("সংগঠনের নাম") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = orgTagline,
                                onValueChange = { orgTagline = it },
                                label = { Text("স্লোগান / ট্যাগলাইন") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = orgHelpline,
                                onValueChange = { orgHelpline = it },
                                label = { Text("জরুরি হটলাইন নম্বর") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = orgAddress,
                                onValueChange = { orgAddress = it },
                                label = { Text("অফিস ও সাংগঠনিক ঠিকানা") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        repository.updateOrgSettings(
                                            OrgSettings(
                                                name = orgName,
                                                tagline = orgTagline,
                                                emergencyHotline = orgHelpline,
                                                address = orgAddress
                                            ),
                                            adminUid = currentUserProfile?.uid ?: "",
                                            adminName = currentUserProfile?.name ?: "Super Admin"
                                        )
                                        settingsSavedMessage = true
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("সেটিংস সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                            }


                            if (settingsSavedMessage) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "সংগঠন সেটিংস সফলভাবে আপডেট করা হয়েছে!",
                                    color = Color(0xFF2E7D32),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Role Change Dialog
        if (selectedUserForRoleChange != null) {
            val user = selectedUserForRoleChange!!
            AlertDialog(
                onDismissRequest = { selectedUserForRoleChange = null },
                title = { Text("দায়িত্ব ও পদবী পরিবর্তন") },
                text = {
                    Column {
                        Text("সদস্য: ${user.name} (${user.email})")
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("নতুন দায়িত্ব নির্বাচন করুন:", fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(6.dp))

                        listOf(
                            UserProfile.ROLE_MEMBER to "সাধারণ সদস্য (Member)",
                            UserProfile.ROLE_VOLUNTEER to "স্বেচ্ছাসেবক (Volunteer)",
                            UserProfile.ROLE_MODERATOR to "মডারেটর (Moderator)",
                            UserProfile.ROLE_ADMIN to "অ্যাডমিন (Admin)"
                        ).forEach { (roleCode, roleLabel) ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { newSelectedRole = roleCode }
                                    .padding(vertical = 4.dp)
                            ) {
                                RadioButton(
                                    selected = newSelectedRole == roleCode,
                                    onClick = { newSelectedRole = roleCode }
                                )
                                Text(roleLabel, fontSize = 13.sp)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                repository.updateUserRole(
                                    targetUid = user.uid,
                                    newRole = newSelectedRole,
                                    performerUid = currentUserProfile?.uid ?: "",
                                    performerName = currentUserProfile?.name ?: "Super Admin"
                                )
                                selectedUserForRoleChange = null
                            }

                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("দায়িত্ব পরিবর্তন নিশ্চিত করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedUserForRoleChange = null }) {
                        Text("বাতিল")
                    }
                }
            )
        }
    }
}

@Composable
fun MemberRoleCard(
    user: UserProfile,
    isSuperAdmin: Boolean,
    onChangeRoleClick: () -> Unit
) {
    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFEBEE)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = user.name.take(1).uppercase(),
                    fontWeight = FontWeight.Bold,
                    color = CrimsonPrimary
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = user.name, fontWeight = FontWeight.Bold)
                Text(text = "${user.email} | ${user.phone}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Surface(
                    color = if (user.isAdminOrHigher) Color(0xFFFFEBEE) else MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = "দায়িত্ব: ${user.role}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (user.isAdminOrHigher) CrimsonPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            if (!isSuperAdmin) {
                IconButton(onClick = onChangeRoleClick) {
                    Icon(Icons.Default.Edit, contentDescription = "Change Role", tint = CrimsonPrimary)
                }
            }
        }
    }
}
