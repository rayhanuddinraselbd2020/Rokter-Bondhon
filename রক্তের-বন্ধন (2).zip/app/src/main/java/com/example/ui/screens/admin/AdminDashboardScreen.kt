package com.example.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.BloodGroupBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NeumorphicCard
import com.example.ui.screens.user.StatCard
import com.example.ui.theme.CrimsonPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateBack: () -> Unit,
    onNavigateToSuperAdmin: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) }

    val bloodRequests by repository.getBloodRequestsFlow().collectAsState(initial = emptyList())
    val donors by repository.getDonorsFlow().collectAsState(initial = emptyList())
    val bloodStock by repository.getBloodStockFlow().collectAsState(initial = emptyList())
    val donations by repository.getDonationsFlow().collectAsState(initial = emptyList())
    val notices by repository.getNoticesFlow().collectAsState(initial = emptyList())
    val bloodCamps by repository.getBloodCampsFlow().collectAsState(initial = emptyList())
    val auditLogs by repository.getAuditLogsFlow().collectAsState(initial = emptyList())

    val totalDonors = donors.size
    val activeRequests = bloodRequests.filter { it.status == BloodRequest.STATUS_PENDING }.size
    val fulfilledRequests = bloodRequests.filter { it.status == BloodRequest.STATUS_FULFILLED }.size
    val totalDonationBags = donations.sumOf { it.units }

    // Dialog states
    var showBroadcastDialog by remember { mutableStateOf(false) }
    var showAddNoticeDialog by remember { mutableStateOf(false) }
    var showAddCampDialog by remember { mutableStateOf(false) }
    var showUpdateStockDialog by remember { mutableStateOf<BloodStockItem?>(null) }
    var stockCountInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("অ্যাডমিন ড্যাশবোর্ড", fontWeight = FontWeight.Bold)
                        Text(
                            text = "বাংলাদেশ সেবামূলক সংগঠন",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = CrimsonPrimary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (currentUserProfile?.isSuperAdmin == true) {
                        IconButton(onClick = onNavigateToSuperAdmin) {
                            Icon(Icons.Default.Shield, contentDescription = "Super Admin", tint = CrimsonPrimary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = CrimsonPrimary,
                edgePadding = 16.dp
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("সারসংক্ষেপ") })
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("রক্তের আবেদন (${bloodRequests.size})") })
                Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("ব্লাড স্টক") })
                Tab(selected = selectedTab == 3, onClick = { selectedTab = 3 }, text = { Text("ক্যাম্প ও নোটিশ") })
                Tab(selected = selectedTab == 4, onClick = { selectedTab = 4 }, text = { Text("অডিট লগ") })
            }

            when (selectedTab) {
                0 -> {
                    // Summary Overview
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Quick Action Buttons
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { showBroadcastDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                ) {
                                    Icon(Icons.Default.BroadcastOnHome, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("ইমার্জেন্সি ব্রডকাস্ট", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (currentUserProfile?.isSuperAdmin == true) {
                                    OutlinedButton(
                                        onClick = onNavigateToSuperAdmin,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                    ) {
                                        Icon(Icons.Default.Shield, contentDescription = null, tint = CrimsonPrimary, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("সুপার অ্যাডমিন", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                                    }
                                }
                            }
                        }

                        // Metrics Grid
                        item {
                            Text(
                                text = "সংগঠনের সামগ্রিক পরিসংখ্যান",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(label = "মোট রক্তদাতা", value = totalDonors.toString(), icon = Icons.Default.People, modifier = Modifier.weight(1f))
                                StatCard(label = "সক্রিয় আবেদন", value = activeRequests.toString(), icon = Icons.Default.HourglassTop, modifier = Modifier.weight(1f))
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatCard(label = "সম্পন্ন আবেদন", value = fulfilledRequests.toString(), icon = Icons.Default.CheckCircle, modifier = Modifier.weight(1f))
                                StatCard(label = "মোট রক্তদান", value = "$totalDonationBags ব্যাগ", icon = Icons.Default.Favorite, modifier = Modifier.weight(1f))
                            }
                        }

                        // Blood Stock Preview
                        item {
                            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "ব্লাড ব্যাংক মজুত পরিস্থিতি",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                BloodStockGrid(
                                    stockList = bloodStock,
                                    onEditStock = { item ->
                                        showUpdateStockDialog = item
                                        stockCountInput = item.availableBags.toString()
                                    }
                                )
                            }
                        }
                    }
                }

                1 -> {
                    // Manage Blood Requests: Approve, Reject, Delete fake
                    if (bloodRequests.isEmpty()) {
                        EmptyStateView(title = "কোনো রক্তের আবেদন নেই", subtitle = "ব্যবহারকারী আবেদন করলে এখানে প্রদর্শিত হবে।")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(bloodRequests) { req ->
                                AdminBloodRequestCard(
                                    request = req,
                                    onApprove = {
                                        coroutineScope.launch {
                                            repository.updateBloodRequestStatus(
                                                requestId = req.id,
                                                status = BloodRequest.STATUS_APPROVED,
                                                adminUid = currentUserProfile?.uid ?: "",
                                                adminName = currentUserProfile?.name ?: "Admin"
                                            )
                                        }
                                    },
                                    onReject = {
                                        coroutineScope.launch {
                                            repository.updateBloodRequestStatus(
                                                requestId = req.id,
                                                status = BloodRequest.STATUS_REJECTED,
                                                adminUid = currentUserProfile?.uid ?: "",
                                                adminName = currentUserProfile?.name ?: "Admin"
                                            )
                                        }
                                    },
                                    onDelete = {
                                        coroutineScope.launch {
                                            repository.deleteBloodRequest(
                                                requestId = req.id,
                                                adminUid = currentUserProfile?.uid ?: "",
                                                adminName = currentUserProfile?.name ?: "Admin"
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                2 -> {
                    // Blood Stock Manager
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Text(
                                text = "রক্তের গ্রুপ অনুযায়ী মজুত ব্যবস্থাপনা",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "যেকোনো গ্রুপের কার্ডে ট্যাপ করে উপলব্ধ ব্যাগের সংখ্যা আপডেট করুন।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        item {
                            BloodStockGrid(
                                stockList = bloodStock,
                                onEditStock = { item ->
                                    showUpdateStockDialog = item
                                    stockCountInput = item.availableBags.toString()
                                }
                            )
                        }
                    }
                }

                3 -> {
                    // Camps and Notices Management
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { showAddCampDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ক্যাম্প যোগ করুন", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = { showAddNoticeDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("নোটিশ দিন", fontSize = 12.sp)
                                }
                            }
                        }

                        item {
                            Text(
                                text = "রক্তদান ক্যাম্প সমূহ (${bloodCamps.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        items(bloodCamps) { camp ->
                            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                                Text(text = camp.title, fontWeight = FontWeight.Bold)
                                Text(text = "তারিখ: ${camp.date} | স্থান: ${camp.venue}, ${camp.location}", fontSize = 12.sp)
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "প্রকাশিত নোটিশ সমূহ (${notices.size})",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        items(notices) { notice ->
                            NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                                Text(text = notice.title, fontWeight = FontWeight.Bold)
                                Text(text = notice.description, fontSize = 12.sp)
                            }
                        }
                    }
                }

                4 -> {
                    // Audit Logs
                    if (auditLogs.isEmpty()) {
                        EmptyStateView(title = "কোনো অডিট লগ নেই", subtitle = "সিস্টেমে কৃত সকল কার্যক্রমের রেকর্ড এখানে সংরক্ষিত হবে।")
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(auditLogs) { log ->
                                NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = log.action, fontWeight = FontWeight.Bold, color = CrimsonPrimary)
                                        Text(text = log.performerName, fontSize = 11.sp, color = Color.Gray)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = log.details, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Emergency Broadcast Dialog
        if (showBroadcastDialog) {
            EmergencyBroadcastDialog(
                onDismiss = { showBroadcastDialog = false },
                onSend = { title, message, bloodGroup ->
                    coroutineScope.launch {
                        repository.sendEmergencyBroadcast(
                            title = title,
                            message = message,
                            targetBloodGroup = bloodGroup,
                            adminUid = currentUserProfile?.uid ?: "",
                            adminName = currentUserProfile?.name ?: "Admin"
                        )
                        showBroadcastDialog = false
                    }
                }
            )
        }

        // Update Stock Dialog
        if (showUpdateStockDialog != null) {
            val stockItem = showUpdateStockDialog!!
            AlertDialog(
                onDismissRequest = { showUpdateStockDialog = null },
                title = { Text("${stockItem.bloodGroup} মজুত আপডেট") },
                text = {
                    OutlinedTextField(
                        value = stockCountInput,
                        onValueChange = { stockCountInput = it },
                        label = { Text("উপলব্ধ রক্তের ব্যাগের সংখ্যা") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val bags = stockCountInput.toIntOrNull() ?: stockItem.availableBags
                            coroutineScope.launch {
                                repository.updateBloodStock(
                                    bloodGroup = stockItem.bloodGroup,
                                    bags = bags,
                                    adminUid = currentUserProfile?.uid ?: "",
                                    adminName = currentUserProfile?.name ?: "Admin"
                                )
                                showUpdateStockDialog = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("সংরক্ষণ করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showUpdateStockDialog = null }) { Text("বাতিল") }
                }
            )
        }


        // Add Notice Dialog
        if (showAddNoticeDialog) {
            var noticeTitle by remember { mutableStateOf("") }
            var noticeDesc by remember { mutableStateOf("") }
            var noticePriority by remember { mutableStateOf("normal") }

            AlertDialog(
                onDismissRequest = { showAddNoticeDialog = false },
                title = { Text("নতুন নোটিশ প্রকাশ") },
                text = {
                    Column {
                        OutlinedTextField(
                            value = noticeTitle,
                            onValueChange = { noticeTitle = it },
                            label = { Text("নোটিশের শিরোনাম") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = noticeDesc,
                            onValueChange = { noticeDesc = it },
                            label = { Text("বিস্তারিত বিবরণ") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (noticeTitle.isNotBlank()) {
                                coroutineScope.launch {
                                    repository.createNotice(
                                        NoticeItem(
                                            title = noticeTitle,
                                            description = noticeDesc,
                                            priority = noticePriority,
                                            publishedBy = currentUserProfile?.name ?: "Admin"
                                        )
                                    )
                                    showAddNoticeDialog = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("প্রকাশ করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddNoticeDialog = false }) { Text("বাতিল") }
                }
            )
        }

        // Add Blood Camp Dialog
        if (showAddCampDialog) {
            var campTitle by remember { mutableStateOf("") }
            var campDate by remember { mutableStateOf("") }
            var campTime by remember { mutableStateOf("সকাল ১০:০০ - বিকাল ০৪:০০") }
            var campVenue by remember { mutableStateOf("") }
            var campLocation by remember { mutableStateOf("ঢাকা") }

            AlertDialog(
                onDismissRequest = { showAddCampDialog = false },
                title = { Text("নতুন রক্তদান ক্যাম্প যোগ করুন") },
                text = {
                    Column {
                        OutlinedTextField(value = campTitle, onValueChange = { campTitle = it }, label = { Text("ক্যাম্পের শিরোনাম") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = campDate, onValueChange = { campDate = it }, label = { Text("তারিখ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = campVenue, onValueChange = { campVenue = it }, label = { Text("ভেন্যু / প্রতিষ্ঠান") }, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(value = campLocation, onValueChange = { campLocation = it }, label = { Text("স্থান ও জেলা") }, modifier = Modifier.fillMaxWidth())
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (campTitle.isNotBlank() && campDate.isNotBlank()) {
                                coroutineScope.launch {
                                    repository.createBloodCamp(
                                        BloodCampItem(
                                            title = campTitle,
                                            date = campDate,
                                            time = campTime,
                                            venue = campVenue,
                                            location = campLocation,
                                            coordinatorName = currentUserProfile?.name ?: "Admin"
                                        )
                                    )
                                    showAddCampDialog = false
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
                    ) {
                        Text("যোগ করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddCampDialog = false }) { Text("বাতিল") }
                }
            )
        }
    }
}

@Composable
fun BloodStockGrid(
    stockList: List<BloodStockItem>,
    onEditStock: (BloodStockItem) -> Unit
) {
    val bloodGroups = BloodCompatibility.ALL_BLOOD_GROUPS
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            bloodGroups.take(4).forEach { bg ->
                val item = stockList.find { it.bloodGroup.equals(bg, ignoreCase = true) } ?: BloodStockItem(bloodGroup = bg, availableBags = 0)
                StockItemCard(item = item, onClick = { onEditStock(item) }, modifier = Modifier.weight(1f))
            }
        }
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            bloodGroups.drop(4).forEach { bg ->
                val item = stockList.find { it.bloodGroup.equals(bg, ignoreCase = true) } ?: BloodStockItem(bloodGroup = bg, availableBags = 0)
                StockItemCard(item = item, onClick = { onEditStock(item) }, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun StockItemCard(
    item: BloodStockItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            BloodGroupBadge(bloodGroup = item.bloodGroup, size = 32.dp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "${item.availableBags} ব্যাগ",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun AdminBloodRequestCard(
    request: BloodRequest,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onDelete: () -> Unit
) {
    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BloodGroupBadge(bloodGroup = request.bloodGroup, size = 44.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "রোগী: ${request.patientName} (${request.units} ব্যাগ)", fontWeight = FontWeight.Bold)
                Text(text = "হাসপাতাল: ${request.hospital}, ${request.location}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(text = "আবেদনকারী: ${request.requesterName} | মোবাইল: ${request.contactNumber}", fontSize = 11.sp, color = CrimsonPrimary)
                Text(text = "স্ট্যাটাস: ${request.status} | জরুরিতা: ${request.urgency}", fontSize = 11.sp)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Outlined.Delete, contentDescription = "Delete fake", tint = Color.Gray)
            }
        }

        if (request.status == BloodRequest.STATUS_PENDING) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("অনুমোদন (Approve)", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = onReject,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("বাতিল (Reject)", fontSize = 12.sp, color = Color.Red)
                }
            }
        }
    }
}

@Composable
fun EmergencyBroadcastDialog(
    onDismiss: () -> Unit,
    onSend: (title: String, message: String, bloodGroup: String) -> Unit
) {
    var title by remember { mutableStateOf("জরুরি রক্তের প্রয়োজন") }
    var message by remember { mutableStateOf("") }
    var selectedBloodGroup by remember { mutableStateOf("সকল") }

    val bloodGroups = listOf("সকল") + BloodCompatibility.ALL_BLOOD_GROUPS

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ইমার্জেন্সি ব্রডকাস্ট অ্যালার্ট", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("নির্ধারিত রক্তের গ্রুপের সকল নিবন্ধিত রক্তদাতার কাছে দ্রুত নোটিফিকেশন পৌঁছাবে।", fontSize = 12.sp)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("বার্তা / হাসপাতালের বিবরণ") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                Spacer(modifier = Modifier.height(8.dp))
                Text("লক্ষ্য রক্তের গ্রুপ:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    bloodGroups.take(5).forEach { bg ->
                        FilterChip(
                            selected = selectedBloodGroup == bg,
                            onClick = { selectedBloodGroup = bg },
                            label = { Text(bg, fontSize = 10.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && message.isNotBlank()) {
                        onSend(title, message, selectedBloodGroup)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary)
            ) {
                Text("ব্রডকাস্ট পাঠান")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
