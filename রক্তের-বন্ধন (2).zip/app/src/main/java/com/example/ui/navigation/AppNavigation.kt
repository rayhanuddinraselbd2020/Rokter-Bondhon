package com.example.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.admin.AdminDashboardScreen
import com.example.ui.screens.admin.SuperAdminScreen
import com.example.ui.screens.auth.LoginScreen
import com.example.ui.screens.auth.RegisterScreen
import com.example.ui.screens.user.*
import com.example.ui.theme.CrimsonPrimary

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Register : Screen("register")
    object Main : Screen("main")
    object CreateRequest : Screen("create_request")
    object DonorSearch : Screen("donor_search")
    object Chat : Screen("chat/{recipientUid}/{recipientName}") {
        fun createRoute(recipientUid: String, recipientName: String) =
            "chat/$recipientUid/${java.net.URLEncoder.encode(recipientName, "UTF-8")}"
    }
    object Notifications : Screen("notifications")
    object Profile : Screen("profile")
    object AdminDashboard : Screen("admin_dashboard")
    object SuperAdmin : Screen("super_admin")
}

enum class BottomTab(val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    HOME("হোম", Icons.Filled.Home, Icons.Outlined.Home),
    DONORS("রক্তদাতা", Icons.Filled.People, Icons.Outlined.People),
    SERVICES("সেবা", Icons.Filled.MedicalServices, Icons.Outlined.MedicalServices),
    ACTIVITIES("কার্যক্রম", Icons.Filled.Event, Icons.Outlined.Event),
    NOTICES("বিজ্ঞপ্তি", Icons.Filled.Campaign, Icons.Outlined.Campaign)
}

@Composable
fun AppNavigation(
    repository: FirebaseRepository,
    navController: NavHostController = rememberNavController()
) {
    val currentUserProfile by repository.currentUserProfileFlow.collectAsState()

    // Protected In-App Call Overlay State
    var activeCallData by remember { mutableStateOf<Pair<String, String>?>(null) } // (Name, BloodGroup)

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                repository = repository,
                onNavigateToHome = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Login.route) {
            LoginScreen(
                repository = repository,
                onLoginSuccess = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(Screen.Register.route)
                }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                repository = repository,
                onRegisterSuccess = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onNavigateToLogin = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.Main.route) {
            MainContainerScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                onNavigateToCreateRequest = { navController.navigate(Screen.CreateRequest.route) },
                onNavigateToChat = { uid, name ->
                    navController.navigate(Screen.Chat.createRoute(uid, name))
                },
                onNavigateToAdminPanel = { navController.navigate(Screen.AdminDashboard.route) },
                onNavigateToNotifications = { navController.navigate(Screen.Notifications.route) },
                onNavigateToProfile = { navController.navigate(Screen.Profile.route) },
                onStartInAppCall = { name, bloodGroup ->
                    activeCallData = Pair(name, bloodGroup)
                }
            )
        }

        composable(Screen.CreateRequest.route) {
            BloodRequestScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                onNavigateBack = { navController.popBackStack() },
                onRequestCreatedSuccess = { navController.popBackStack() }
            )
        }

        composable(Screen.Notifications.route) {
            NotificationsScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(Screen.Profile.route) {
            ProfileScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                onNavigateToAdminPanel = { navController.navigate(Screen.AdminDashboard.route) },
                onSignOut = {
                    repository.signOut()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Chat.route) { backStackEntry ->
            val recipientUid = backStackEntry.arguments?.getString("recipientUid") ?: ""
            val rawName = backStackEntry.arguments?.getString("recipientName") ?: ""
            val recipientName = java.net.URLDecoder.decode(rawName, "UTF-8")

            ChatScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                recipientUid = recipientUid,
                recipientName = recipientName,
                onNavigateBack = { navController.popBackStack() },
                onStartCall = {
                    activeCallData = Pair(recipientName, "")
                }
            )
        }

        composable(Screen.AdminDashboard.route) {
            AdminDashboardScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToSuperAdmin = { navController.navigate(Screen.SuperAdmin.route) }
            )
        }

        composable(Screen.SuperAdmin.route) {
            SuperAdminScreen(
                repository = repository,
                currentUserProfile = currentUserProfile,
                onNavigateBack = { navController.popBackStack() }
            )
        }
    }

    // Floating protected voice call modal
    if (activeCallData != null) {
        val (contactName, bloodGroup) = activeCallData!!
        InAppCallDialog(
            contactName = contactName,
            bloodGroup = bloodGroup,
            onEndCall = { activeCallData = null }
        )
    }
}

@Composable
fun MainContainerScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    onNavigateToCreateRequest: () -> Unit,
    onNavigateToChat: (uid: String, name: String) -> Unit,
    onNavigateToAdminPanel: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToProfile: () -> Unit,
    onStartInAppCall: (name: String, bloodGroup: String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(BottomTab.HOME) }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                BottomTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title,
                                tint = if (isSelected) CrimsonPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) CrimsonPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFFFFEBEE)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                BottomTab.HOME -> {
                    HomeScreen(
                        repository = repository,
                        currentUserProfile = currentUserProfile,
                        onNavigateToCreateRequest = onNavigateToCreateRequest,
                        onNavigateToDonorSearch = { selectedTab = BottomTab.DONORS },
                        onNavigateToChat = onNavigateToChat,
                        onNavigateToAdminPanel = onNavigateToAdminPanel,
                        onNavigateToNotifications = onNavigateToNotifications,
                        onNavigateToProfile = onNavigateToProfile
                    )
                }
                BottomTab.DONORS -> {
                    DonorSearchScreen(
                        repository = repository,
                        currentUserProfile = currentUserProfile,
                        onNavigateBack = { selectedTab = BottomTab.HOME },
                        onStartChat = onNavigateToChat,
                        onStartInAppCall = onStartInAppCall
                    )
                }
                BottomTab.SERVICES -> {
                    ServicesScreen(
                        repository = repository,
                        currentUserProfile = currentUserProfile,
                        onNavigateToCreateBloodRequest = onNavigateToCreateRequest
                    )
                }
                BottomTab.ACTIVITIES -> {
                    ActivitiesScreen(
                        repository = repository
                    )
                }
                BottomTab.NOTICES -> {
                    NoticesScreen(
                        repository = repository
                    )
                }
            }
        }
    }
}
