package com.example.ui.screens.user

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BloodCompatibility
import com.example.data.model.DonorProfile
import com.example.data.model.UserProfile
import com.example.data.repository.FirebaseRepository
import com.example.ui.components.BloodGroupBadge
import com.example.ui.components.EmptyStateView
import com.example.ui.components.NeumorphicCard
import com.example.ui.theme.CrimsonPrimary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonorSearchScreen(
    repository: FirebaseRepository,
    currentUserProfile: UserProfile?,
    initialBloodGroup: String? = null,
    onNavigateBack: () -> Unit,
    onStartChat: (donorUid: String, donorName: String) -> Unit,
    onStartInAppCall: (donorName: String, bloodGroup: String) -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val allDonors by repository.getDonorsFlow().collectAsState(initial = emptyList())

    var selectedBloodGroup by remember { mutableStateOf(initialBloodGroup ?: "সকল") }
    var locationQuery by remember { mutableStateOf("") }
    var availableOnly by remember { mutableStateOf(true) }
    var includeCompatible by remember { mutableStateOf(true) }

    val bloodGroupsFilter = listOf("সকল") + BloodCompatibility.ALL_BLOOD_GROUPS

    // Filter logic
    val filteredDonors = remember(allDonors, selectedBloodGroup, locationQuery, availableOnly, includeCompatible) {
        allDonors.filter { donor ->
            // Filter out own profile from search
            val isNotSelf = donor.uid != currentUserProfile?.uid

            // Availability filter
            val matchesAvailability = if (availableOnly) {
                donor.isAvailable && !donor.isCurrentlyOnCooldown
            } else true

            // Blood group filter
            val matchesBloodGroup = if (selectedBloodGroup == "সকল") {
                true
            } else if (includeCompatible) {
                // If patient needs selectedBloodGroup, find compatible donors
                val compatibleDonors = BloodCompatibility.getCompatibleDonors(selectedBloodGroup)
                compatibleDonors.contains(donor.bloodGroup)
            } else {
                donor.bloodGroup.equals(selectedBloodGroup, ignoreCase = true)
            }

            // Location filter
            val matchesLocation = if (locationQuery.isBlank()) {
                true
            } else {
                donor.district.contains(locationQuery, ignoreCase = true)
            }

            isNotSelf && matchesAvailability && matchesBloodGroup && matchesLocation
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("রক্তদাতা অনুসন্ধান", fontWeight = FontWeight.Bold)
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Filter Header Controls
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 1.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Location Search Bar
                    OutlinedTextField(
                        value = locationQuery,
                        onValueChange = { locationQuery = it },
                        placeholder = { Text("জেলা বা এলাকা দিয়ে খুঁজুন (উদাঃ ঢাকা)") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CrimsonPrimary) },
                        trailingIcon = {
                            if (locationQuery.isNotBlank()) {
                                IconButton(onClick = { locationQuery = "" }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Blood Group Pills
                    Text(
                        text = "রক্তের গ্রুপ নির্বাচন:",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(bloodGroupsFilter) { bg ->
                            val isSelected = selectedBloodGroup == bg
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedBloodGroup = bg },
                                label = { Text(bg, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = CrimsonPrimary,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Compatibility and Availability Toggles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = availableOnly,
                                onCheckedChange = { availableOnly = it },
                                colors = CheckboxDefaults.colors(checkedColor = CrimsonPrimary)
                            )
                            Text("শুধু প্রস্তুত দাতা", fontSize = 12.sp)
                        }

                        if (selectedBloodGroup != "সকল") {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = includeCompatible,
                                    onCheckedChange = { includeCompatible = it },
                                    colors = CheckboxDefaults.colors(checkedColor = CrimsonPrimary)
                                )
                                Text("সামঞ্জস্যপূর্ণ গ্রুপসহ", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Results count and header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "উপলব্ধ রক্তদাতা (${filteredDonors.size} জন)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "সুরক্ষিত যোগাযোগ",
                    style = MaterialTheme.typography.bodySmall.copy(color = CrimsonPrimary, fontSize = 11.sp)
                )
            }

            // Donors List
            if (filteredDonors.isEmpty()) {
                EmptyStateView(
                    title = "কোনো রক্তদাতা পাওয়া যায়নি",
                    subtitle = "আপনার ফিল্টার অনুযায়ী বর্তমানে কোনো রক্তদাতা প্রস্তুত নেই। ফিল্টার পরিবর্তন করে পুনরায় চেষ্টা করুন।",
                    icon = Icons.Outlined.SearchOff
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredDonors) { donor ->
                        DonorSearchCard(
                            donor = donor,
                            onChatClick = { onStartChat(donor.uid, donor.name) },
                            onCallClick = { onStartInAppCall(donor.name, donor.bloodGroup) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DonorSearchCard(
    donor: DonorProfile,
    onChatClick: () -> Unit,
    onCallClick: () -> Unit
) {
    NeumorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BloodGroupBadge(bloodGroup = donor.bloodGroup, size = 48.dp)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = donor.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    // Badge: verified or donor rank
                    Surface(
                        color = Color(0xFFFFF8E1),
                        shape = RoundedCornerShape(6.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB300))
                    ) {
                        Text(
                            text = donor.badge,
                            color = Color(0xFFE65100),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "জেলা: ${donor.district}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Masked phone for privacy
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = Color.Gray
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "নম্বর: ${donor.maskedPhone} (গোপনীয়)",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    )
                }

                if (donor.totalDonations > 0) {
                    Text(
                        text = "ইতিমধ্যে ${donor.totalDonations} বার রক্তদান করেছেন",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 11.sp,
                            color = CrimsonPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Protected Communication Actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onChatClick,
                colors = ButtonDefaults.buttonColors(containerColor = CrimsonPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
            ) {
                Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("বার্তা পাঠান", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onCallClick,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(40.dp)
            ) {
                Icon(Icons.Default.PhoneInTalk, contentDescription = null, modifier = Modifier.size(18.dp), tint = CrimsonPrimary)
                Spacer(modifier = Modifier.width(6.dp))
                Text("ইন-অ্যাপ কল", fontSize = 13.sp, color = CrimsonPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }
}
