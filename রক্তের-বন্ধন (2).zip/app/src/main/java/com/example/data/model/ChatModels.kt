package com.example.data.model

data class Conversation(
    val id: String = "",
    val participantUids: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis(),
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)

data class ChatMessage(
    val id: String = "",
    val conversationId: String = "",
    val senderUid: String = "",
    val senderName: String = "",
    val text: String = "",
    val imageUrl: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val seen: Boolean = false,
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)

data class NotificationItem(
    val id: String = "",
    val userUid: String = "", // specific uid or "broadcast"
    val title: String = "",
    val message: String = "",
    val type: String = "general", // "blood_match", "emergency_broadcast", "request_approved", "request_accepted", "cooldown_reminder", "notice", "event"
    val targetId: String = "",
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)
