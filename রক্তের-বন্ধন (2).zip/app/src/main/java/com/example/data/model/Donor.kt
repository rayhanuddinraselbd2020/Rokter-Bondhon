package com.example.data.model

data class DonorProfile(
    val uid: String = "",
    val name: String = "",
    val bloodGroup: String = "",
    val phone: String = "",
    val district: String = "",
    val isAvailable: Boolean = true,
    val gender: String = "male",
    val lastDonationDate: Long = 0L,
    val cooldownUntil: Long = 0L,
    val totalDonations: Int = 0,
    val badge: String = "রক্তযোদ্ধা", // Blood fighter / Donor badge
    val isVerified: Boolean = false,
    val organizationId: String = UserProfile.DEFAULT_ORG_ID,
    val updatedAt: Long = System.currentTimeMillis()
) {
    val isCurrentlyOnCooldown: Boolean
        get() = cooldownUntil > System.currentTimeMillis()

    val cooldownDaysRemaining: Long
        get() {
            val diff = cooldownUntil - System.currentTimeMillis()
            return if (diff > 0) (diff / (1000 * 60 * 60 * 24)) + 1 else 0
        }

    val maskedPhone: String
        get() {
            if (phone.length < 6) return phone
            val start = phone.take(3)
            val end = phone.takeLast(2)
            val mask = "*".repeat((phone.length - 5).coerceAtLeast(3))
            return "$start$mask$end"
        }
}

object BloodCompatibility {
    val ALL_BLOOD_GROUPS = listOf("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")

    fun getCompatibleRecipients(donorGroup: String): List<String> {
        return when (donorGroup.trim().uppercase()) {
            "O-" -> listOf("O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+")
            "O+" -> listOf("O+", "A+", "B+", "AB+")
            "A-" -> listOf("A-", "A+", "AB-", "AB+")
            "A+" -> listOf("A+", "AB+")
            "B-" -> listOf("B-", "B+", "AB-", "AB+")
            "B+" -> listOf("B+", "AB+")
            "AB-" -> listOf("AB-", "AB+")
            "AB+" -> listOf("AB+")
            else -> emptyList()
        }
    }

    fun getCompatibleDonors(recipientGroup: String): List<String> {
        return when (recipientGroup.trim().uppercase()) {
            "AB+" -> listOf("O-", "O+", "A-", "A+", "B-", "B+", "AB-", "AB+")
            "AB-" -> listOf("O-", "A-", "B-", "AB-")
            "A+" -> listOf("O-", "O+", "A-", "A+")
            "A-" -> listOf("O-", "A-")
            "B+" -> listOf("O-", "O+", "B-", "B+")
            "B-" -> listOf("O-", "B-")
            "O+" -> listOf("O-", "O+")
            "O-" -> listOf("O-")
            else -> emptyList()
        }
    }

    fun isCompatible(donorGroup: String, recipientGroup: String): Boolean {
        return getCompatibleRecipients(donorGroup).contains(recipientGroup.trim().uppercase())
    }
}
