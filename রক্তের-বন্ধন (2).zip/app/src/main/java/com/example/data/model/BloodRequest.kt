package com.example.data.model

data class BloodRequest(
    val id: String = "",
    val patientName: String = "",
    val bloodGroup: String = "",
    val hospital: String = "",
    val location: String = "",
    val requiredDate: String = "",
    val units: Int = 1,
    val contactNumber: String = "",
    val urgency: String = URGENCY_NORMAL, // "Normal", "Urgent", "Critical"
    val medicalReportUrl: String = "",
    val requesterUid: String = "",
    val requesterName: String = "",
    val status: String = STATUS_PENDING, // "Pending", "Approved", "Fulfilled", "Rejected"
    val acceptedDonorUid: String = "",
    val acceptedDonorName: String = "",
    val organizationId: String = UserProfile.DEFAULT_ORG_ID,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val URGENCY_NORMAL = "Normal"
        const val URGENCY_URGENT = "Urgent"
        const val URGENCY_CRITICAL = "Critical"

        const val STATUS_PENDING = "Pending"
        const val STATUS_APPROVED = "Approved"
        const val STATUS_FULFILLED = "Fulfilled"
        const val STATUS_REJECTED = "Rejected"
    }

    val maskedContact: String
        get() {
            if (contactNumber.length < 6) return contactNumber
            val start = contactNumber.take(3)
            val end = contactNumber.takeLast(2)
            val mask = "*".repeat((contactNumber.length - 5).coerceAtLeast(3))
            return "$start$mask$end"
        }
}
