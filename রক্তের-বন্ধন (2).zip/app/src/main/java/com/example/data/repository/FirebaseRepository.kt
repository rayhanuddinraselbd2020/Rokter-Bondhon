package com.example.data.repository

import com.example.data.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class FirebaseRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    private val repositoryScope = CoroutineScope(Dispatchers.IO)
    private val _currentUserProfile = MutableStateFlow<UserProfile?>(null)
    val currentUserProfileFlow: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user == null) {
                _currentUserProfile.value = null
            } else {
                attachUserProfileListener(user.uid)
            }
        }
    }

    private fun attachUserProfileListener(uid: String) {
        firestore.collection(COLL_USERS).document(uid)
            .addSnapshotListener { snapshot, _ ->
                if (snapshot != null && snapshot.exists()) {
                    _currentUserProfile.value = snapshot.toObject(UserProfile::class.java)
                } else if (auth.currentUser != null) {
                    val fallback = UserProfile(
                        uid = uid,
                        email = auth.currentUser?.email ?: "",
                        name = auth.currentUser?.displayName ?: "User",
                        role = if (uid == UserProfile.SUPER_ADMIN_UID) UserProfile.ROLE_SUPER_ADMIN else UserProfile.ROLE_MEMBER
                    )
                    _currentUserProfile.value = fallback
                }
            }
    }


    companion object {
        private const val COLL_USERS = "users"
        private const val COLL_DONORS = "donors"
        private const val COLL_BLOOD_REQUESTS = "bloodRequests"
        private const val COLL_MATCHES = "bloodRequestMatches"
        private const val COLL_DONATIONS = "donations"
        private const val COLL_STOCK = "bloodStock"
        private const val COLL_CAMPS = "bloodCamps"
        private const val COLL_ACTIVITIES = "activities"
        private const val COLL_NOTICES = "notices"
        private const val COLL_EVENTS = "events"
        private const val COLL_SERVICES = "services"
        private const val COLL_SERVICE_REQUESTS = "serviceRequests"
        private const val COLL_CONVERSATIONS = "conversations"
        private const val COLL_MESSAGES = "messages"
        private const val COLL_NOTIFICATIONS = "notifications"
        private const val COLL_VERIFICATIONS = "donorVerifications"
        private const val COLL_AUDIT_LOGS = "auditLogs"
        private const val COLL_ORGANIZATIONS = "organizations"
    }

    // --- Authentication & Profile ---

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    val currentUid: String?
        get() = auth.currentUser?.uid

    suspend fun signIn(email: String, pass: String): Result<UserProfile> = runCatching {
        val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
        val uid = result.user?.uid ?: throw IllegalStateException("User ID not found")
        val snapshot = firestore.collection(COLL_USERS).document(uid).get().await()
        if (snapshot.exists()) {
            snapshot.toObject(UserProfile::class.java) ?: UserProfile(uid = uid, email = email)
        } else {
            // Document creation fallback if missing
            val newProfile = UserProfile(
                uid = uid,
                email = email,
                name = result.user?.displayName ?: email.substringBefore("@"),
                role = if (uid == UserProfile.SUPER_ADMIN_UID) UserProfile.ROLE_SUPER_ADMIN else UserProfile.ROLE_MEMBER
            )
            firestore.collection(COLL_USERS).document(uid).set(newProfile).await()
            newProfile
        }
    }

    suspend fun register(
        name: String,
        email: String,
        pass: String,
        phone: String,
        photoUrl: String,
        bloodGroup: String,
        gender: String,
        district: String
    ): Result<UserProfile> = runCatching {
        val authResult = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
        val uid = authResult.user?.uid ?: throw IllegalStateException("Registration failed to return UID")

        // Strict role check: New users ALWAYS start as member, unless hardcoded super admin UID
        val role = if (uid == UserProfile.SUPER_ADMIN_UID) UserProfile.ROLE_SUPER_ADMIN else UserProfile.ROLE_MEMBER

        val profile = UserProfile(
            uid = uid,
            name = name.trim(),
            email = email.trim(),
            phone = phone.trim(),
            photoUrl = photoUrl.trim(),
            role = role,
            organizationId = UserProfile.DEFAULT_ORG_ID,
            status = "active",
            bloodGroup = bloodGroup.trim().uppercase(),
            gender = gender.lowercase(),
            district = district.trim(),
            isAvailable = true,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )

        firestore.collection(COLL_USERS).document(uid).set(profile).await()

        // Also register in donors collection
        val donor = DonorProfile(
            uid = uid,
            name = profile.name,
            bloodGroup = profile.bloodGroup,
            phone = profile.phone,
            district = profile.district,
            gender = profile.gender,
            isAvailable = true,
            totalDonations = 0,
            badge = "নতুন রক্তদাতা",
            isVerified = false,
            organizationId = UserProfile.DEFAULT_ORG_ID,
            updatedAt = System.currentTimeMillis()
        )
        firestore.collection(COLL_DONORS).document(uid).set(donor).await()

        // Create welcome notification
        createNotification(
            NotificationItem(
                userUid = uid,
                title = "স্বাগতম রক্তের বন্ধন-এ!",
                message = "বাংলাদেশ সেবামূলক সংগঠনে যোগ দেওয়ার জন্য ধন্যবাদ। মানবতার কল্যাণে আপনার রক্তদান বাঁচাবে জীবন।",
                type = "welcome"
            )
        )

        profile
    }

    fun getUserProfileFlow(uid: String): Flow<UserProfile?> = callbackFlow {
        val listener = firestore.collection(COLL_USERS).document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(null)
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    trySend(snapshot.toObject(UserProfile::class.java))
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateAvailability(uid: String, isAvailable: Boolean): Result<Unit> = runCatching {
        firestore.collection(COLL_USERS).document(uid)
            .update("isAvailable", isAvailable, "updatedAt", System.currentTimeMillis()).await()
        firestore.collection(COLL_DONORS).document(uid)
            .update("isAvailable", isAvailable, "updatedAt", System.currentTimeMillis()).await()
    }

    fun signOut() {
        auth.signOut()
    }

    // --- Blood Requests ---

    suspend fun createBloodRequest(request: BloodRequest): Result<String> = runCatching {
        val docRef = firestore.collection(COLL_BLOOD_REQUESTS).document()
        val reqWithId = request.copy(
            id = docRef.id,
            createdAt = System.currentTimeMillis(),
            status = BloodRequest.STATUS_PENDING
        )
        docRef.set(reqWithId).await()

        // Match compatible donors in donors collection
        val compatibleDonorGroups = BloodCompatibility.getCompatibleDonors(reqWithId.bloodGroup)
        val donorSnapshots = firestore.collection(COLL_DONORS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .whereEqualTo("isAvailable", true)
            .get().await()

        val matchingDonors = donorSnapshots.toObjects(DonorProfile::class.java).filter { donor ->
            compatibleDonorGroups.contains(donor.bloodGroup) && !donor.isCurrentlyOnCooldown
        }

        val currentTime = System.currentTimeMillis()
        for (donor in matchingDonors) {
            // Save match record
            val matchRef = firestore.collection(COLL_MATCHES).document()
            val matchData = mapOf(
                "id" to matchRef.id,
                "requestId" to reqWithId.id,
                "donorUid" to donor.uid,
                "status" to "notified",
                "matchedAt" to currentTime,
                "organizationId" to UserProfile.DEFAULT_ORG_ID
            )
            matchRef.set(matchData)

            // Notify matching donor
            createNotification(
                NotificationItem(
                    userUid = donor.uid,
                    title = if (reqWithId.urgency == BloodRequest.URGENCY_CRITICAL)
                        "🚨 জরুরি রক্তের প্রয়োজন: ${reqWithId.bloodGroup}"
                    else "রক্তদানের আহ্বান: ${reqWithId.bloodGroup}",
                    message = "${reqWithId.hospital}, ${reqWithId.location}-এ ${reqWithId.units} ব্যাগ ${reqWithId.bloodGroup} রক্ত প্রয়োজন। আপনি প্রস্তুত থাকলে সাড়া দিন।",
                    type = if (reqWithId.urgency == BloodRequest.URGENCY_CRITICAL) "emergency_broadcast" else "blood_match",
                    targetId = reqWithId.id
                )
            )
        }

        // If Critical, also log audit and notify broadcast
        if (reqWithId.urgency == BloodRequest.URGENCY_CRITICAL) {
            logAudit(
                performedByUid = reqWithId.requesterUid,
                performedByName = reqWithId.requesterName,
                action = "EMERGENCY_BROADCAST",
                details = "Critical emergency request created for ${reqWithId.bloodGroup} at ${reqWithId.hospital}"
            )
        }

        docRef.id
    }

    fun getBloodRequestsFlow(): Flow<List<BloodRequest>> = callbackFlow {
        val listener = firestore.collection(COLL_BLOOD_REQUESTS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(BloodRequest::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun getUserBloodRequestsFlow(uid: String): Flow<List<BloodRequest>> = callbackFlow {
        val listener = firestore.collection(COLL_BLOOD_REQUESTS)
            .whereEqualTo("requesterUid", uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(BloodRequest::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun acceptBloodRequest(requestId: String, donorUid: String, donorName: String): Result<Unit> = runCatching {
        val docRef = firestore.collection(COLL_BLOOD_REQUESTS).document(requestId)
        val snapshot = docRef.get().await()
        val request = snapshot.toObject(BloodRequest::class.java) ?: throw IllegalStateException("Request not found")

        docRef.update(
            mapOf(
                "acceptedDonorUid" to donorUid,
                "acceptedDonorName" to donorName,
                "status" to BloodRequest.STATUS_APPROVED
            )
        ).await()

        // Notify requester
        createNotification(
            NotificationItem(
                userUid = request.requesterUid,
                title = "রক্তদাতা গ্রহণ করেছেন!",
                message = "$donorName আপনার রক্তের অনুরোধ গ্রহণ করেছেন। ইন-অ্যাপ চ্যাট বা কলের মাধ্যমে যোগাযোগ করুন।",
                type = "request_accepted",
                targetId = requestId
            )
        )

        // Automatically start conversation between requester and donor
        getOrCreateConversation(
            userAId = request.requesterUid,
            userAName = request.requesterName,
            userBId = donorUid,
            userBName = donorName
        )
    }

    suspend fun fulfillBloodRequest(
        requestId: String,
        donorUid: String,
        donorName: String,
        bloodGroup: String,
        units: Int,
        patientName: String,
        hospital: String,
        donorGender: String = "male"
    ): Result<Unit> = runCatching {
        // 1. Mark request fulfilled
        firestore.collection(COLL_BLOOD_REQUESTS).document(requestId).update(
            "status", BloodRequest.STATUS_FULFILLED
        ).await()

        val now = System.currentTimeMillis()
        // 2. Add donation record
        val donationDoc = firestore.collection(COLL_DONATIONS).document()
        val donationRecord = DonationRecord(
            id = donationDoc.id,
            donorUid = donorUid,
            donorName = donorName,
            bloodGroup = bloodGroup,
            requestId = requestId,
            patientName = patientName,
            hospital = hospital,
            units = units,
            donationDate = now,
            organizationId = UserProfile.DEFAULT_ORG_ID
        )
        donationDoc.set(donationRecord).await()

        // 3. Cooldown calculation: 90 days for male, 120 days for female
        val cooldownDays = if (donorGender.equals("female", ignoreCase = true)) 120L else 90L
        val cooldownMillis = now + (cooldownDays * 24 * 60 * 60 * 1000)

        // 4. Update donor profile
        val donorDoc = firestore.collection(COLL_DONORS).document(donorUid)
        val donorSnap = donorDoc.get().await()
        val curDonations = donorSnap.getLong("totalDonations")?.toInt() ?: 0
        val newDonationCount = curDonations + 1

        val newBadge = when {
            newDonationCount >= 25 -> "প্লাটিনাম দাতা"
            newDonationCount >= 10 -> "স্বর্ণ দাতা"
            newDonationCount >= 5 -> "রৌপ্য দাতা"
            else -> "রক্তযোদ্ধা"
        }

        donorDoc.update(
            mapOf(
                "lastDonationDate" to now,
                "cooldownUntil" to cooldownMillis,
                "isAvailable" to false,
                "totalDonations" to newDonationCount,
                "badge" to newBadge,
                "updatedAt" to now
            )
        ).await()

        // Also update users collection
        firestore.collection(COLL_USERS).document(donorUid).update(
            mapOf(
                "lastDonationDate" to now,
                "isAvailable" to false,
                "updatedAt" to now
            )
        ).await()

        // Notify donor
        createNotification(
            NotificationItem(
                userUid = donorUid,
                title = "রক্তদানের জন্য ধন্যবাদ!",
                message = "আপনার রক্তদান সম্পন্ন হয়েছে। একটি জীবন বাঁচাতে আপনার ভূমিকা প্রশংসনীয়। পরবর্তী $cooldownDays দিন আপনার কুলডাউন থাকবে।",
                type = "donation_fulfilled",
                targetId = donationDoc.id
            )
        )
    }

    // --- Donors & Compatibility ---

    fun getDonorsFlow(): Flow<List<DonorProfile>> = callbackFlow {
        val listener = firestore.collection(COLL_DONORS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(DonorProfile::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // --- Chat & Communication ---

    suspend fun getOrCreateConversation(
        userAId: String,
        userAName: String,
        userBId: String,
        userBName: String
    ): Result<String> = runCatching {
        val sortedUids = listOf(userAId, userBId).sorted()
        val convId = "${sortedUids[0]}_${sortedUids[1]}"
        val docRef = firestore.collection(COLL_CONVERSATIONS).document(convId)
        val snapshot = docRef.get().await()
        if (!snapshot.exists()) {
            val conv = Conversation(
                id = convId,
                participantUids = sortedUids,
                participantNames = mapOf(userAId to userAName, userBId to userBName),
                lastMessage = "কথোপকথন শুরু হয়েছে",
                lastMessageTime = System.currentTimeMillis()
            )
            docRef.set(conv).await()
        }
        convId
    }

    fun getConversationsFlow(uid: String): Flow<List<Conversation>> = callbackFlow {
        val listener = firestore.collection(COLL_CONVERSATIONS)
            .whereArrayContains("participantUids", uid)
            .orderBy("lastMessageTime", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(Conversation::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun getMessagesFlow(conversationId: String): Flow<List<ChatMessage>> = callbackFlow {
        val listener = firestore.collection(COLL_CONVERSATIONS).document(conversationId)
            .collection(COLL_MESSAGES)
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(ChatMessage::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(
        conversationId: String,
        text: String,
        imageUrl: String = "",
        senderUid: String,
        senderName: String
    ): Result<Unit> = runCatching {
        val now = System.currentTimeMillis()
        val msgRef = firestore.collection(COLL_CONVERSATIONS).document(conversationId)
            .collection(COLL_MESSAGES).document()

        val msg = ChatMessage(
            id = msgRef.id,
            conversationId = conversationId,
            senderUid = senderUid,
            senderName = senderName,
            text = text,
            imageUrl = imageUrl,
            timestamp = now,
            seen = false
        )
        msgRef.set(msg).await()

        firestore.collection(COLL_CONVERSATIONS).document(conversationId).update(
            mapOf(
                "lastMessage" to if (text.isNotBlank()) text else "📷 ছবি পাঠানো হয়েছে",
                "lastMessageTime" to now
            )
        ).await()
    }

    // --- Notifications ---

    suspend fun createNotification(notification: NotificationItem): Result<String> = runCatching {
        val doc = firestore.collection(COLL_NOTIFICATIONS).document()
        val item = notification.copy(id = doc.id, createdAt = System.currentTimeMillis())
        doc.set(item).await()
        doc.id
    }

    fun getNotificationsFlow(uid: String): Flow<List<NotificationItem>> = callbackFlow {
        val listener = firestore.collection(COLL_NOTIFICATIONS)
            .whereIn("userUid", listOf(uid, "broadcast"))
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(NotificationItem::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun markNotificationAsRead(id: String): Result<Unit> = runCatching {
        firestore.collection(COLL_NOTIFICATIONS).document(id).update("isRead", true).await()
    }

    // --- Notices & Activities & Events & Services ---

    fun getNoticesFlow(): Flow<List<NoticeItem>> = callbackFlow {
        val listener = firestore.collection(COLL_NOTICES)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(NoticeItem::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createNotice(notice: NoticeItem, adminUid: String, adminName: String): Result<Unit> = runCatching {
        val doc = firestore.collection(COLL_NOTICES).document()
        doc.set(notice.copy(id = doc.id, createdAt = System.currentTimeMillis())).await()

        // Broadcast notice to all
        createNotification(
            NotificationItem(
                userUid = "broadcast",
                title = "নতুন বিজ্ঞপ্তি: ${notice.title}",
                message = notice.description,
                type = "notice",
                targetId = doc.id
            )
        )

        logAudit(adminUid, adminName, "CREATE_NOTICE", "Notice created: ${notice.title}")
    }

    fun getActivitiesFlow(): Flow<List<ActivityItem>> = callbackFlow {
        val listener = firestore.collection(COLL_ACTIVITIES)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(ActivityItem::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createActivity(activity: ActivityItem, adminUid: String, adminName: String): Result<Unit> = runCatching {
        val doc = firestore.collection(COLL_ACTIVITIES).document()
        doc.set(activity.copy(id = doc.id, createdAt = System.currentTimeMillis())).await()
        logAudit(adminUid, adminName, "CREATE_ACTIVITY", "Activity created: ${activity.title}")
    }

    fun getBloodCampsFlow(): Flow<List<BloodCampItem>> = callbackFlow {
        val listener = firestore.collection(COLL_CAMPS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(BloodCampItem::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createBloodCamp(camp: BloodCampItem, adminUid: String, adminName: String): Result<Unit> = runCatching {
        val doc = firestore.collection(COLL_CAMPS).document()
        doc.set(camp.copy(id = doc.id)).await()
        createNotification(
            NotificationItem(
                userUid = "broadcast",
                title = "রক্তদান ক্যাম্প: ${camp.title}",
                message = "তারিখ: ${camp.date}, ভেন্যু: ${camp.venue}, ${camp.location}। অংশ নিন ও রক্তদান করুন।",
                type = "event",
                targetId = doc.id
            )
        )
        logAudit(adminUid, adminName, "CREATE_BLOOD_CAMP", "Blood Camp scheduled: ${camp.title}")
    }

    fun getBloodStockFlow(): Flow<List<BloodStockItem>> = callbackFlow {
        val listener = firestore.collection(COLL_STOCK)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(BloodStockItem::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateBloodStock(bloodGroup: String, bags: Int, adminUid: String = "admin", adminName: String = "Admin"): Result<Unit> = runCatching {
        val doc = firestore.collection(COLL_STOCK).document(bloodGroup.trim().uppercase())
        val stockItem = BloodStockItem(
            bloodGroup = bloodGroup.trim().uppercase(),
            availableBags = bags.coerceAtLeast(0),
            lastUpdated = System.currentTimeMillis()
        )
        doc.set(stockItem).await()
        logAudit(adminUid, adminName, "UPDATE_BLOOD_STOCK", "Stock updated for $bloodGroup to $bags bags")
    }


    // --- Members & Volunteers ---

    fun getMembersFlow(): Flow<List<UserProfile>> = callbackFlow {
        val listener = firestore.collection(COLL_USERS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(UserProfile::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun updateMemberStatus(targetUid: String, newStatus: String, adminUid: String, adminName: String): Result<Unit> = runCatching {
        firestore.collection(COLL_USERS).document(targetUid).update("status", newStatus).await()
        logAudit(adminUid, adminName, "UPDATE_USER_STATUS", "User $targetUid status changed to $newStatus")
    }

    // --- Super Admin Powers ---

    suspend fun updateUserRole(targetUid: String, newRole: String, performerUid: String, performerName: String): Result<Unit> = runCatching {
        // Can only be performed if performer is super admin
        firestore.collection(COLL_USERS).document(targetUid).update(
            mapOf("role" to newRole, "updatedAt" to System.currentTimeMillis())
        ).await()
        logAudit(performerUid, performerName, "UPDATE_ROLE", "User $targetUid role changed to $newRole")
    }

    fun getAuditLogsFlow(): Flow<List<AuditLogItem>> = callbackFlow {
        val listener = firestore.collection(COLL_AUDIT_LOGS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(AuditLogItem::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun logAudit(performedByUid: String, performedByName: String, action: String, details: String) {
        runCatching {
            val doc = firestore.collection(COLL_AUDIT_LOGS).document()
            val log = AuditLogItem(
                id = doc.id,
                performedByUid = performedByUid,
                performedByName = performedByName,
                action = action,
                details = details,
                timestamp = System.currentTimeMillis()
            )
            doc.set(log).await()
        }
    }

    fun getDonationsFlow(): Flow<List<DonationRecord>> = callbackFlow {
        val listener = firestore.collection(COLL_DONATIONS)
            .whereEqualTo("organizationId", UserProfile.DEFAULT_ORG_ID)
            .orderBy("donationDate", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(emptyList())
                    return@addSnapshotListener
                }
                val list = snapshot?.toObjects(DonationRecord::class.java) ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun sendEmergencyBroadcast(
        title: String,
        message: String,
        targetBloodGroup: String,
        adminUid: String,
        adminName: String
    ): Result<Unit> = runCatching {
        val compatibleDonorGroups = if (targetBloodGroup.isNotBlank()) {
            BloodCompatibility.getCompatibleDonors(targetBloodGroup)
        } else {
            BloodCompatibility.ALL_BLOOD_GROUPS
        }

        // Send notification item
        createNotification(
            NotificationItem(
                userUid = "broadcast",
                title = "🚨 জরুরি ব্রডকাস্ট: $title",
                message = message,
                type = "emergency_broadcast"
            )
        )

        logAudit(adminUid, adminName, "EMERGENCY_BROADCAST", "Sent emergency broadcast for blood group: $targetBloodGroup. Message: $message")
    }

    suspend fun deleteBloodRequest(requestId: String, adminUid: String, adminName: String): Result<Unit> = runCatching {
        firestore.collection(COLL_BLOOD_REQUESTS).document(requestId).delete().await()
        logAudit(adminUid, adminName, "DELETE_BLOOD_REQUEST", "Deleted blood request: $requestId")
    }

    suspend fun updateBloodRequestStatus(
        requestId: String,
        status: String,
        adminUid: String,
        adminName: String
    ): Result<Unit> = runCatching {
        firestore.collection(COLL_BLOOD_REQUESTS).document(requestId).update("status", status).await()
        logAudit(adminUid, adminName, "UPDATE_REQUEST_STATUS", "Updated request $requestId status to $status")
    }

    fun getAllUsersFlow(): Flow<List<UserProfile>> = getMembersFlow()

    fun getChatMessagesFlow(conversationId: String): Flow<List<ChatMessage>> = getMessagesFlow(conversationId)

    suspend fun sendMessage(
        chatId: String,
        senderUid: String,
        senderName: String,
        recipientUid: String,
        recipientName: String,
        text: String
    ): Result<Unit> = runCatching {
        getOrCreateConversation(senderUid, senderName, recipientUid, recipientName)
        sendMessage(
            conversationId = chatId,
            text = text,
            imageUrl = "",
            senderUid = senderUid,
            senderName = senderName
        )
    }

    suspend fun createNotice(notice: NoticeItem): Result<Unit> =
        createNotice(notice, "system", "অ্যাডমিন প্যানেল")

    suspend fun createBloodCamp(camp: BloodCampItem): Result<Unit> =
        createBloodCamp(camp, "system", "অ্যাডমিন প্যানেল")

    fun getOrgSettingsFlow(): Flow<OrgSettings> = callbackFlow {

        val docRef = firestore.collection(COLL_ORGANIZATIONS).document(UserProfile.DEFAULT_ORG_ID)
        val listener = docRef.addSnapshotListener { snapshot, _ ->
            if (snapshot != null && snapshot.exists()) {
                trySend(snapshot.toObject(OrgSettings::class.java) ?: OrgSettings())
            } else {
                trySend(OrgSettings())
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun updateOrgSettings(
        settings: OrgSettings,
        adminUid: String,
        adminName: String
    ): Result<Unit> = runCatching {
        firestore.collection(COLL_ORGANIZATIONS).document(UserProfile.DEFAULT_ORG_ID).set(settings).await()
        logAudit(adminUid, adminName, "UPDATE_ORG_SETTINGS", "Updated organization settings")
    }
}

