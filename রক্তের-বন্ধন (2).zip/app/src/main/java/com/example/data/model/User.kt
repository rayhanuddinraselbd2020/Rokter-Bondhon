package com.example.data.model

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val photoUrl: String = "",
    val role: String = ROLE_MEMBER, // "member", "admin", "super_admin"
    val organizationId: String = DEFAULT_ORG_ID,
    val status: String = "active", // "active", "inactive", "banned"
    val bloodGroup: String = "",
    val gender: String = "male", // "male", "female", "other"
    val district: String = "",
    val lastDonationDate: Long = 0L,
    val isAvailable: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val DEFAULT_ORG_ID = "bangladesh_sebamulok_songothon"
        const val ROLE_MEMBER = "member"
        const val ROLE_VOLUNTEER = "volunteer"
        const val ROLE_MODERATOR = "moderator"
        const val ROLE_ADMIN = "admin"
        const val ROLE_SUPER_ADMIN = "super_admin"
        const val SUPER_ADMIN_UID = "DM3NTudltkRV3ecrodNsGd4HfwE2"
    }


    val isSuperAdmin: Boolean
        get() = role == ROLE_SUPER_ADMIN || uid == SUPER_ADMIN_UID

    val isAdminOrHigher: Boolean
        get() = role == ROLE_ADMIN || role == ROLE_SUPER_ADMIN || uid == SUPER_ADMIN_UID

    val maskedPhone: String
        get() {
            if (phone.length < 6) return phone
            val start = phone.take(3)
            val end = phone.takeLast(2)
            val mask = "*".repeat((phone.length - 5).coerceAtLeast(3))
            return "$start$mask$end"
        }
}
