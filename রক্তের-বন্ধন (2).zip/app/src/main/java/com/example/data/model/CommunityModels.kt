package com.example.data.model

data class DonationRecord(
    val id: String = "",
    val donorUid: String = "",
    val donorName: String = "",
    val bloodGroup: String = "",
    val requestId: String = "",
    val patientName: String = "",
    val hospital: String = "",
    val units: Int = 1,
    val donationDate: Long = System.currentTimeMillis(),
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)

data class BloodStockItem(
    val bloodGroup: String = "",
    val availableBags: Int = 0,
    val lastUpdated: Long = System.currentTimeMillis(),
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)

data class BloodCampItem(
    val id: String = "",
    val title: String = "",
    val location: String = "",
    val venue: String = "",
    val date: String = "",
    val time: String = "",
    val expectedDonors: Int = 50,
    val coordinatorName: String = "",
    val contactPhone: String = "",
    val status: String = "Upcoming", // "Upcoming", "Completed", "Cancelled"
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)

data class NoticeItem(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val priority: String = "Normal", // "Normal", "Urgent", "Important"
    val publishedBy: String = "অ্যাডমিন প্যানেল",
    val organizationId: String = UserProfile.DEFAULT_ORG_ID,
    val createdAt: Long = System.currentTimeMillis()
)

data class ActivityItem(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val imageUrl: String = "",
    val date: String = "",
    val category: String = "রক্তদান কর্মসূচি",
    val organizationId: String = UserProfile.DEFAULT_ORG_ID,
    val createdAt: Long = System.currentTimeMillis()
)

data class ServiceItem(
    val id: String = "",
    val name: String = "",
    val description: String = "",
    val iconName: String = "blood", // "blood", "ambulance", "oxygen", "medicine", "consultation"
    val contactNumber: String = "",
    val category: String = "জরুরি সেবা",
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
)

data class ServiceRequest(
    val id: String = "",
    val serviceId: String = "",
    val serviceName: String = "",
    val applicantName: String = "",
    val phone: String = "",
    val details: String = "",
    val status: String = "Pending",
    val organizationId: String = UserProfile.DEFAULT_ORG_ID,
    val createdAt: Long = System.currentTimeMillis()
)

data class DonorVerification(
    val id: String = "",
    val donorUid: String = "",
    val donorName: String = "",
    val phone: String = "",
    val nidOrIdProofUrl: String = "",
    val status: String = "Pending", // "Pending", "Verified", "Rejected"
    val verifiedByAdminUid: String = "",
    val organizationId: String = UserProfile.DEFAULT_ORG_ID,
    val submittedAt: Long = System.currentTimeMillis()
)

data class AuditLogItem(
    val id: String = "",
    val performedByUid: String = "",
    val performedByName: String = "",
    val action: String = "",
    val details: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val organizationId: String = UserProfile.DEFAULT_ORG_ID
) {
    val performerName: String get() = performedByName
}

data class OrgSettings(
    val id: String = UserProfile.DEFAULT_ORG_ID,
    val name: String = "Bangladesh Sebamulok Songothon",
    val banglaName: String = "বাংলাদেশ সেবামূলক সংগঠন",
    val tagline: String = "Manusher Pashe, Manobatar Jonno",
    val banglaTagline: String = "মানুষের পাশে, মানবতার জন্য",
    val emergencyHotline: String = "+8801700000000",
    val email: String = "contact@sebamulok.org",
    val address: String = "ঢাকা, বাংলাদেশ",
    val superAdminUid: String = UserProfile.SUPER_ADMIN_UID,
    val emergencyBroadcastEnabled: Boolean = true
) {
    val helpline: String get() = emergencyHotline
}

